package com.airil.rillrebirth

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.parseColor("#F2F2F7")
    private val ink = Color.parseColor("#1C1C1E")
    private val subtle = Color.parseColor("#8E8E93")
    private val green = Color.parseColor("#2F6F4F")
    private val greenSoft = Color.parseColor("#E3F1E9")
    private val line = Color.parseColor("#ECECF1")
    private var scrollView: ScrollView? = null
    private var lastTab = ""
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selectedTab = "Home"
    private var tasks = mutableListOf<RillTask>()
    private var done = mutableSetOf<Int>()
    private var selectedWorkoutId = -1L
    private var timerDuration = 90L
    private var timerRemaining = 90L
    private var timerRunning = false
    private var timerEndAt = 0L
    private var timerMode = "Istirahat"
    private var timerLabel: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val timerTick = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            timerRemaining = ((timerEndAt - SystemClock.elapsedRealtime() + 999) / 1000).coerceAtLeast(0)
            timerLabel?.text = formatTime(timerRemaining)
            if (timerRemaining <= 0) {
                timerRunning = false
                try { val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 75); tone.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 500) } catch (_: Exception) {}
                Toast.makeText(this@MainActivity, "Waktu timer selesai!", Toast.LENGTH_LONG).show()
            } else handler.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tasks = TaskStore.load(this)
        done = TaskStore.doneToday(this)
        createNotificationChannel()
        render()
        ReminderScheduler.scheduleAll(this)
        maybePromptMood()
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) { tasks = TaskStore.load(this); done = TaskStore.doneToday(this); render(); maybePromptMood() } }
    override fun onDestroy() { handler.removeCallbacks(timerTick); super.onDestroy() }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("rill_data", Context.MODE_PRIVATE)
    private fun shape(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }
    private fun drawable(id: Int) = resources.getDrawable(id, theme)
    private fun text(value: String, size: Float, bold: Boolean = false, color: Int = ink): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(dp(2), dp(3), dp(2), dp(3))
    }
    private fun button(label: String, primary: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f; setTypeface(typeface, android.graphics.Typeface.BOLD)
        stateListAnimator = null; elevation = 0f; minHeight = 0; minimumHeight = 0
        setTextColor(if (primary) Color.WHITE else green)
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#22000000")), shape(if (primary) green else greenSoft, 14), shape(Color.BLACK, 14))
        val lp = LinearLayout.LayoutParams(-1, dp(48)); lp.setMargins(0, dp(6), 0, dp(6)); layoutParams = lp
        setOnClickListener { action() }
    }
    private fun card(vPad: Int = 14): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(vPad), dp(16), dp(vPad)); background = shape(Color.WHITE, 20)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(6), 0, dp(6)); layoutParams = lp
    }
    private fun pbar(maxV: Int, value: Int): ProgressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = maxV; progress = value; progressDrawable = drawable(R.drawable.progress_green)
        layoutParams = LinearLayout.LayoutParams(-1, dp(8)).apply { setMargins(0, dp(8), 0, dp(8)) }
    }
    private fun divider(): View = View(this).apply { setBackgroundColor(line); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) }
    private fun section(title: String) { content.addView(text(title, 18f, true).apply { setPadding(dp(4), dp(14), dp(4), dp(4)) }) }
    private fun chevron(): ImageView = ImageView(this).apply { setImageResource(R.drawable.ic_chevron); setColorFilter(subtle) }

    private fun checkRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit, onDetail: (() -> Unit)? = null): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(12)) }
        val cb = CheckBox(this).apply { setButtonDrawable(R.drawable.cb_selector); setPadding(0, 0, 0, 0); minWidth = 0; minHeight = 0; isChecked = checked; setOnCheckedChangeListener { _, v -> onChange(v) } }
        r.addView(cb, LinearLayout.LayoutParams(dp(26), dp(26)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(8), 0) }
        col.addView(text(title, 15f, false, ink)); if (sub.isNotBlank()) col.addView(text(sub, 12f, false, subtle))
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (onDetail != null) r.addView(chevron().apply { setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { onDetail() } }, LinearLayout.LayoutParams(dp(36), dp(36)))
        r.setOnClickListener { cb.toggle() }
        return r
    }
    private fun listItem(title: String, sub: String, onClick: () -> Unit): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, dp(12)) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(title, 15f, false, ink)); if (sub.isNotBlank()) col.addView(text(sub, 12f, false, subtle))
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(chevron(), LinearLayout.LayoutParams(dp(18), dp(18)))
        r.setOnClickListener { onClick() }
        return r
    }
    private fun pair(a: Button, b: Button): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(0, dp(6), dp(4), dp(6)) })
        addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), dp(6), 0, dp(6)) })
    }

    private fun buildNav(): LinearLayout {
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(6), dp(6), dp(6)); background = shape(Color.WHITE, 30); elevation = dp(3).toFloat() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(14), dp(4), dp(14), dp(12)); nav.layoutParams = lp
        listOf(Triple("Home", "Beranda", R.drawable.ic_home), Triple("Checklist", "Checklist", R.drawable.ic_checklist), Triple("Workout", "Workout", R.drawable.ic_workout), Triple("Jadwal", "Jadwal", R.drawable.ic_calendar), Triple("Statistik", "Statistik", R.drawable.ic_stats)).forEach { (key, label, icon) ->
            val sel = selectedTab == key
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)); if (sel) background = shape(greenSoft, 22); setOnClickListener { selectedTab = key; render() } }
            item.addView(ImageView(this).apply { setImageResource(icon); setColorFilter(if (sel) green else subtle) }, LinearLayout.LayoutParams(dp(22), dp(22)))
            item.addView(TextView(this).apply { text = label; textSize = 10f; gravity = Gravity.CENTER; maxLines = 1; setTextColor(if (sel) green else subtle); if (sel) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, dp(2), 0, 0) })
            nav.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        return nav
    }

    private fun render() {
        val keepY = if (lastTab == selectedTab) (scrollView?.scrollY ?: 0) else 0
        lastTab = selectedTab
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val titles = mapOf("Home" to "Beranda", "Checklist" to "Checklist", "Workout" to "Workout", "Jadwal" to "Jadwal", "Statistik" to "Statistik")
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(6)) }
        header.addView(text(titles[selectedTab] ?: selectedTab, 30f, true, ink)); header.addView(text("RilHabit · Pelan-pelan, konsisten.", 13f, false, subtle)); root.addView(header)
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }; scrollView = scroll
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(6), dp(16), dp(16)) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        when (selectedTab) { "Home" -> showHome(); "Checklist" -> showChecklist(); "Workout" -> showWorkout(); "Jadwal" -> showSchedule(); "Statistik" -> showStats() }
        root.addView(buildNav())
        setContentView(root)
        if (keepY > 0) scroll.post { scroll.scrollTo(0, keepY) }
    }

    private fun showHome() {
        val currentXp = TaskStore.xpFor(this, done) + WorkoutStore.workoutXpToday(this); val totalXp = TaskStore.totalXp(this) + WorkoutStore.totalWorkoutXp(this); val level = totalXp / 100 + 1
        val progress = if (tasks.isEmpty()) 0 else (done.size * 100 / tasks.size)
        val c = card()
        c.addView(text("Progres hari ini", 12f, false, subtle)); c.addView(text("${done.size} dari ${tasks.size}", 32f, true, ink)); c.addView(text("kegiatan selesai · $progress%", 13f, false, subtle)); c.addView(pbar(100, progress))
        val meta = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        meta.addView(text("Level $level · $totalXp EXP", 12f, false, subtle), LinearLayout.LayoutParams(0, -2, 1f)); meta.addView(text("+$currentXp EXP hari ini", 12f, true, green)); c.addView(meta); content.addView(c)
        val sessions = WorkoutStore.sessionsForDate(this); val finished = sessions.count { WorkoutStore.isDone(this, it.id) }
        val w = card(); w.addView(text("Workout hari ini", 16f, true)); w.addView(text(if (sessions.isEmpty()) "Tidak ada workout terjadwal hari ini" else "$finished dari ${sessions.size} sesi selesai", 14f, false, subtle)); w.addView(button("Buka Workout") { selectedTab = "Workout"; render() }); content.addView(w)
        val note = card(); note.addView(text("Daily Note", 16f, true))
        val edit = EditText(this).apply { hint = "Tulis catatan singkat untuk hari ini…"; minLines = 2; textSize = 14f; gravity = Gravity.TOP; background = shape(bg, 12); setPadding(dp(12), dp(10), dp(12), dp(10)); setText(prefs().getString("daily_note_${TaskStore.today()}", "") ?: "") }
        note.addView(edit, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, dp(4)) })
        note.addView(button("Simpan catatan") { prefs().edit().putString("daily_note_${TaskStore.today()}", edit.text.toString()).apply(); Toast.makeText(this, "Daily Note tersimpan.", Toast.LENGTH_SHORT).show() }); content.addView(note)
        val mood = WorkoutStore.mood(this, TaskStore.today()); val m = card(); m.addView(text("Mood hari ini", 16f, true)); m.addView(text(if (mood == null) "Belum dicatat" else "${mood.optInt("value")}/5 · ${mood.optString("note")}", 14f, false, subtle)); m.addView(button(if (mood == null) "Catat Mood" else "Ubah Mood") { showMoodDialog(false) }); content.addView(m)
        content.addView(button("Buka checklist harian", true) { selectedTab = "Checklist"; render() })
    }

    private fun showChecklist() {
        val sessions = WorkoutStore.sessionsForDate(this)
        val total = tasks.size + sessions.size; val completed = done.size + sessions.count { WorkoutStore.isDone(this, it.id) }
        val summary = card(); summary.addView(text("$completed dari $total item selesai", 14f, false, subtle)); summary.addView(pbar(100, if (total == 0) 0 else completed * 100 / total)); content.addView(summary)
        section("Tugas harian")
        val sorted = tasks.sortedBy { it.time }
        if (sorted.isNotEmpty()) {
            val list = card(2)
            sorted.forEachIndexed { i, task ->
                list.addView(checkRow(task.name, "${task.time} · ${task.category} · ${task.xp} EXP", done.contains(task.id), { checked -> if (checked) done.add(task.id) else done.remove(task.id); TaskStore.saveDone(this@MainActivity, done); render(); maybePromptMood() }))
                if (i < sorted.size - 1) list.addView(divider())
            }
            content.addView(list)
        }
        section("Workout terjadwal")
        if (sessions.isEmpty()) content.addView(text("Belum ada workout untuk hari ini. Kamu bisa menambahkannya dari menu Workout.", 13f, false, subtle))
        else {
            val list = card(2)
            sessions.forEachIndexed { i, session ->
                list.addView(checkRow(session.name, "${session.time} · ${session.durationMinutes} menit", WorkoutStore.isDone(this, session.id), { checked -> WorkoutStore.setDone(this@MainActivity, session.id, checked); render(); maybePromptMood() }, { selectedWorkoutId = session.id; selectedTab = "Workout"; render(); showWorkoutDetail(session.id) }))
                if (i < sessions.size - 1) list.addView(divider())
            }
            content.addView(list)
        }
        content.addView(button("Evaluasi malam") { showReviewDialog() })
        content.addView(button("Catat Mood sekarang") { showMoodDialog(false) })
    }

    private fun showWorkout() {
        val sessions = WorkoutStore.sessionsForDate(this)
        val dash = card(); dash.addView(text("Sesi hari ini", 17f, true))
        if (sessions.isEmpty()) dash.addView(text("Tidak ada workout terjadwal hari ini", 14f, false, subtle))
        sessions.forEach { s -> dash.addView(text("${s.time} · ${s.name} · ${s.durationMinutes} menit${if (WorkoutStore.isDone(this, s.id)) " · SELESAI" else ""}", 14f, true)); dash.addView(button("Lihat detail sesi") { selectedWorkoutId = s.id; showWorkoutDetail(s.id) }) }
        dash.addView(text("Workout Streak: ${WorkoutStore.currentStreak(this)} hari", 16f, true, green)); dash.addView(text("Rekor terbaik: ${WorkoutStore.bestStreak(this)} hari", 13f, false, subtle)); content.addView(dash)
        val weekCount = (-6..0).count { WorkoutStore.workoutDayActive(this, WorkoutStore.date(it)) }
        val target = prefs().getInt("weekly_workout_goal", 4)
        val goal = card(); goal.addView(text("Target mingguan", 16f, true)); goal.addView(text("$weekCount/$target hari aktif minggu ini", 14f, false, subtle)); goal.addView(pbar(target, weekCount.coerceAtMost(target)))
        goal.addView(button("Ubah target mingguan") { val e = EditText(this).apply { inputType = 2; setText(target.toString()); hint = "Target hari per minggu" }; AlertDialog.Builder(this, R.style.RillDialog).setTitle("Target mingguan").setView(e).setPositiveButton("Simpan") { _, _ -> prefs().edit().putInt("weekly_workout_goal", (e.text.toString().toIntOrNull() ?: 4).coerceIn(1, 7)).apply(); render() }.setNegativeButton("Batal", null).show() }); content.addView(goal)
        content.addView(button("+ Buat workout", true) { editWorkout(null) })
        content.addView(pair(button("Program siap pakai") { showPrograms() }, button("Timer Workout") { showTimer() }))
        section("Program & jadwal saya")
        WorkoutStore.load(this).forEach { s ->
            val c = card(); c.addView(text(s.name, 15f, true)); c.addView(text("${if (s.active) "Aktif" else "Dijeda"} · ${s.time} · ${s.durationMinutes} menit", 12f, false, subtle))
            c.addView(button("Buka sesi / checklist gerakan") { selectedWorkoutId = s.id; showWorkoutDetail(s.id) })
            c.addView(pair(button("Edit workout") { editWorkout(s) }, button(if (s.active) "Jeda program" else "Aktifkan program") { s.active = !s.active; WorkoutStore.save(this, WorkoutStore.load(this).map { if (it.id == s.id) s else it }); ReminderScheduler.scheduleAll(this); render() }))
            content.addView(c)
        }
    }

    private fun showWorkoutDetail(id: Long) {
        val session = WorkoutStore.load(this).find { it.id == id } ?: run { render(); return }
        content.removeAllViews(); scrollView?.scrollTo(0, 0)
        content.addView(text("‹ Workout", 15f, true, green).apply { setPadding(dp(4), dp(4), dp(4), dp(10)); setOnClickListener { render() } })
        content.addView(text(session.name, 24f, true)); content.addView(text("${session.time} · ${session.durationMinutes} menit", 13f, false, subtle)); if (session.notes.isNotBlank()) content.addView(text(session.notes, 13f, false, subtle))
        content.addView(text("Centang setiap gerakan yang sudah selesai. Progres tersimpan otomatis.", 12f, false, subtle).apply { setPadding(dp(2), dp(8), dp(2), dp(4)) })
        val checked = WorkoutStore.exerciseChecks(this, id)
        val list = card(2)
        session.exercises.forEachIndexed { index, exercise ->
            list.addView(checkRow(exercise.name, "${exercise.sets} set × ${exercise.reps} repetisi", checked.contains(index), { value -> val next = WorkoutStore.exerciseChecks(this@MainActivity, id); if (value) next.add(index) else next.remove(index); WorkoutStore.saveExerciseChecks(this@MainActivity, id, next) }))
            if (index < session.exercises.size - 1) list.addView(divider())
        }
        content.addView(list)
        content.addView(pair(button("Timer istirahat") { timerMode = "Istirahat"; showTimer() }, button("Timer bebas") { timerMode = "Bebas"; showTimer() }))
        val isDone = WorkoutStore.isDone(this, id)
        content.addView(button(if (isDone) "Batalkan status selesai" else "Selesaikan Workout", !isDone) {
            val wasDone = WorkoutStore.isDone(this, id); WorkoutStore.setDone(this, id, !wasDone)
            if (!wasDone) Toast.makeText(this, "Workout selesai! Streak: ${WorkoutStore.currentStreak(this)} hari", Toast.LENGTH_SHORT).show()
            render(); maybePromptMood()
        })
    }

    private fun showPrograms() {
        val options = arrayOf("Beginner Movement", "Bodyweight Basics", "Walking & Jogging")
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Pilih program latihan").setItems(options) { _, which ->
            val template = when (which) {
                0 -> listOf(WorkoutExercise("Jalan di tempat", 2, "60 detik"), WorkoutExercise("Squat", 2, "8–10"), WorkoutExercise("Peregangan ringan", 2, "20 detik"))
                1 -> listOf(WorkoutExercise("Squat", 3, "8–12"), WorkoutExercise("Wall Push Up", 3, "8–12"), WorkoutExercise("Glute Bridge", 3, "10–12"), WorkoutExercise("Plank", 2, "15–30 detik"))
                else -> listOf(WorkoutExercise("Jalan santai", 1, "10 menit"), WorkoutExercise("Jalan cepat / jogging ringan", 1, "10–20 menit"), WorkoutExercise("Pendinginan", 1, "5 menit"))
            }
            val name = options[which]; val s = WorkoutSession(System.currentTimeMillis(), name, "18:00", 25, mutableSetOf(Calendar.MONDAY, Calendar.WEDNESDAY, Calendar.FRIDAY), "", "Program siap pakai; sesuaikan dengan kemampuanmu.", false, true, template.toMutableList()); editWorkout(s)
        }.setNegativeButton("Batal", null).show()
    }

    private fun editWorkout(existing: WorkoutSession?) {
        val s = existing ?: WorkoutSession(System.currentTimeMillis(), "", "18:00", 30, mutableSetOf(Calendar.MONDAY, Calendar.WEDNESDAY, Calendar.FRIDAY), "", "", false, true, mutableListOf(WorkoutExercise("Gerakan 1", 3, "8–12")))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(4), dp(18), dp(4)) }
        val name = EditText(this).apply { hint = "Nama workout"; setText(s.name) }
        val time = EditText(this).apply { hint = "Waktu HH:MM"; setText(s.time) }
        val duration = EditText(this).apply { hint = "Durasi menit"; inputType = 2; setText(s.durationMinutes.toString()) }
        val days = EditText(this).apply { hint = "Hari berulang: Sen, Rab, Jum (kosong = sekali)"; setText(if (s.days.isEmpty()) "" else s.days.sorted().joinToString(",") { dayShort(it) }) }
        val date = EditText(this).apply { hint = "Tanggal sekali jalan YYYY-MM-DD (opsional)"; setText(s.oneOffDate) }
        val notes = EditText(this).apply { hint = "Catatan workout (opsional)"; setText(s.notes); minLines = 2 }
        val exercises = EditText(this).apply { hint = "Gerakan, satu per baris. Contoh: Squat | 3 set | 8–12"; setText(s.exercises.joinToString("\n") { "${it.name} | ${it.sets} set | ${it.reps}" }); minLines = 4 }
        val reminder = CheckBox(this).apply { text = "Pengingat harian"; isChecked = s.reminder }
        listOf(name, time, duration, days, date, notes, exercises, reminder).forEach { box.addView(it) }
        AlertDialog.Builder(this, R.style.RillDialog).setTitle(if (existing == null) "Buat workout" else "Edit workout").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Simpan") { _, _ ->
            val t = time.text.toString().trim(); if (name.text.isNullOrBlank() || !Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(t)) { Toast.makeText(this, "Isi nama dan waktu HH:MM yang valid.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
            s.name = name.text.toString().trim(); s.time = String.format(Locale.US, "%02d:%02d", t.substringBefore(":").toInt(), t.substringAfter(":").toInt()); s.durationMinutes = (duration.text.toString().toIntOrNull() ?: 30).coerceIn(1, 600); s.oneOffDate = date.text.toString().trim(); s.notes = notes.text.toString(); s.reminder = reminder.isChecked
            val dayText = days.text.toString().trim(); s.days = if (dayText.isBlank()) mutableSetOf() else parseDays(dayText)
            s.exercises = exercises.text.toString().lines().mapNotNull { line -> val parts = line.split("|").map { it.trim() }; if (parts[0].isBlank()) null else WorkoutExercise(parts[0], parts.getOrNull(1)?.filter { it.isDigit() }?.toIntOrNull() ?: 3, parts.getOrNull(2) ?: "8–12") }.toMutableList()
            val all = WorkoutStore.load(this); if (existing == null) all.add(s) else { val idx = all.indexOfFirst { it.id == s.id }; if (idx >= 0) all[idx] = s else all.add(s) }; WorkoutStore.save(this, all); ReminderScheduler.scheduleAll(this); render()
        }.setNeutralButton(if (existing == null) "Batal" else "Arsipkan") { _, _ -> if (existing != null) { val all = WorkoutStore.load(this); all.find { it.id == s.id }?.active = false; WorkoutStore.save(this, all); render() } }.setNegativeButton("Tutup", null).show()
    }

    private fun parseDays(raw: String): MutableSet<Int> {
        val out = mutableSetOf<Int>(); raw.split(",", " ", ";").map { it.trim().lowercase(Locale.ROOT) }.forEach { when (it) { "min", "minggu", "sun" -> out.add(Calendar.SUNDAY); "sen", "senin", "mon" -> out.add(Calendar.MONDAY); "sel", "selasa", "tue" -> out.add(Calendar.TUESDAY); "rab", "rabu", "wed" -> out.add(Calendar.WEDNESDAY); "kam", "kamis", "thu" -> out.add(Calendar.THURSDAY); "jum", "jumat", "jum'at", "fri" -> out.add(Calendar.FRIDAY); "sab", "sabtu", "sat" -> out.add(Calendar.SATURDAY) } }; return out
    }
    private fun dayShort(d: Int) = when (d) { Calendar.SUNDAY -> "Min"; Calendar.MONDAY -> "Sen"; Calendar.TUESDAY -> "Sel"; Calendar.WEDNESDAY -> "Rab"; Calendar.THURSDAY -> "Kam"; Calendar.FRIDAY -> "Jum"; else -> "Sab" }

    private fun showTimer() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(22), dp(12), dp(22), dp(12)) }
        val label = text(formatTime(timerRemaining), 38f, true, green).apply { gravity = Gravity.CENTER }; timerLabel = label; box.addView(label)
        box.addView(text("Mode: $timerMode", 14f, false, subtle).apply { gravity = Gravity.CENTER })
        val duration = EditText(this).apply { hint = "Durasi dalam detik"; inputType = 2; setText(timerDuration.toString()) }; box.addView(duration)
        box.addView(button("Atur durasi") { val sec = duration.text.toString().toLongOrNull()?.coerceIn(1, 86400) ?: timerDuration; timerDuration = sec; timerRemaining = sec; timerRunning = false; handler.removeCallbacks(timerTick); label.text = formatTime(sec) })
        box.addView(button(if (timerRunning) "Jeda" else "Mulai / Lanjutkan") { if (timerRunning) { timerRunning = false; handler.removeCallbacks(timerTick) } else { if (timerRemaining <= 0) timerRemaining = timerDuration; timerRunning = true; timerEndAt = SystemClock.elapsedRealtime() + timerRemaining * 1000; handler.removeCallbacks(timerTick); handler.post(timerTick) } })
        box.addView(button("Reset") { timerRunning = false; handler.removeCallbacks(timerTick); timerRemaining = timerDuration; label.text = formatTime(timerRemaining) })
        val mode = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Istirahat antar-gerakan", "Timer bebas")); setSelection(if (timerMode == "Bebas") 1 else 0); onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { timerMode = if (position == 1) "Bebas" else "Istirahat" } } }; box.addView(mode)
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Workout Timer").setView(box).setPositiveButton("Selesai", null).show()
    }
    private fun formatTime(seconds: Long): String = String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)

    private fun showSchedule() {
        content.addView(text("Tugas dan workout disimpan di perangkat. Pengingat bergantung pada izin Android/MIUI.", 13f, false, subtle))
        content.addView(button("Tambah kegiatan checklist", true) { editTask(null) })
        content.addView(button("Pengingat tugas: ${if (prefs().getBoolean("reminders_enabled", true)) "Aktif" else "Nonaktif"}") { val on = !prefs().getBoolean("reminders_enabled", true); prefs().edit().putBoolean("reminders_enabled", on).apply(); ReminderScheduler.scheduleAll(this); render() })
        section("Kegiatan")
        if (tasks.isNotEmpty()) {
            val list = card(2); val sorted = tasks.sortedBy { it.time }
            sorted.forEachIndexed { i, t -> list.addView(listItem(t.name, "${t.time} · ${t.category}") { editTask(t) }); if (i < sorted.size - 1) list.addView(divider()) }
            content.addView(list)
        }
        section("Workout")
        content.addView(button("Tambah / edit jadwal workout") { selectedTab = "Workout"; render() })
        val wl = card(); WorkoutStore.load(this).forEach { s -> wl.addView(text("${s.name} · ${if (s.oneOffDate.isNotBlank()) s.oneOffDate else s.days.sorted().joinToString(", ") { dayShort(it) }} · ${if (s.active) "Aktif" else "Dijeda/arsip"}", 13f, false, subtle)) }; content.addView(wl)
    }
    private fun editTask(existing: RillTask?) {
        val task = existing ?: RillTask((tasks.maxOfOrNull { it.id } ?: 0) + 1, "", "18:00", "Umum", 10, false)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
        val name = EditText(this).apply { hint = "Nama kegiatan"; setText(task.name) }; val time = EditText(this).apply { hint = "HH:MM"; setText(task.time) }; val category = EditText(this).apply { hint = "Kategori"; setText(task.category) }; val xp = EditText(this).apply { hint = "EXP (angka)"; setText(task.xp.toString()); inputType = 2 }; val reminder = CheckBox(this).apply { text = "Aktifkan pengingat harian"; isChecked = task.reminderEnabled }
        box.addView(name); box.addView(time); box.addView(category); box.addView(xp); box.addView(reminder)
        AlertDialog.Builder(this, R.style.RillDialog).setTitle(if (existing == null) "Tambah kegiatan" else "Edit kegiatan").setView(box).setPositiveButton("Simpan") { _, _ ->
            val tv = time.text.toString().trim(); val valid = Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(tv); if (name.text.isNullOrBlank() || !valid) { Toast.makeText(this, "Isi nama dan waktu HH:MM yang valid.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
            task.name = name.text.toString().trim(); task.time = String.format(Locale.US, "%02d:%02d", tv.substringBefore(":").toInt(), tv.substringAfter(":").toInt()); task.category = category.text.toString().ifBlank { "Umum" }; task.xp = (xp.text.toString().toIntOrNull() ?: 10).coerceIn(0, 500); task.reminderEnabled = reminder.isChecked
            if (existing == null) tasks.add(task); TaskStore.save(this, tasks); ReminderScheduler.scheduleAll(this); render()
        }.setNeutralButton(if (existing != null) "Hapus" else "Batal") { _, _ -> if (existing != null) { tasks.removeAll { it.id == task.id }; done.remove(task.id); TaskStore.save(this, tasks); TaskStore.saveDone(this, done); ReminderScheduler.scheduleAll(this); render() } }.setNegativeButton("Tutup", null).show()
    }

    private fun showStats() {
        val c = card(); c.addView(text("Statistik Workout", 18f, true)); val sessions = WorkoutStore.load(this); val completedCount = sessions.sumOf { s -> (-29..0).count { WorkoutStore.isDone(this, s.id, WorkoutStore.date(it)) } }; c.addView(text("Sesi selesai dalam 30 hari terakhir: $completedCount", 14f)); c.addView(text("Streak saat ini: ${WorkoutStore.currentStreak(this)} hari · Rekor: ${WorkoutStore.bestStreak(this)} hari", 14f)); c.addView(text("Target mingguan: ${prefs().getInt("weekly_workout_goal", 4)} hari", 14f)); content.addView(c)
        val history = card(); history.addView(text("Riwayat workout · 7 hari", 16f, true)); for (off in -6..0) { val d = WorkoutStore.date(off); val count = WorkoutStore.completedIds(this, d).size; history.addView(text("$d · $count sesi selesai", 13f)) }; content.addView(history)
        val moods = WorkoutStore.moods(this); val moodCard = card(); moodCard.addView(text("Kurva Mood", 18f, true)); val period = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("7 hari", "1 bulan")) }; moodCard.addView(period)
        val graph = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; moodCard.addView(graph)
        fun drawMood(days: Int) { graph.removeAllViews(); val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US); val cal = Calendar.getInstance(); val values = mutableListOf<Pair<String, Int?>>(); for (off in days - 1 downTo 0) { cal.time = Date(); cal.add(Calendar.DAY_OF_YEAR, -off); val d = fmt.format(cal.time); values.add(d to moods.optJSONObject(d)?.optInt("value")) }; values.forEach { (d, v) -> val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }; row.addView(text(d.substring(5), 11f, false, subtle), LinearLayout.LayoutParams(dp(48), -2)); val bar = pbar(5, v ?: 0); row.addView(bar, LinearLayout.LayoutParams(0, dp(12), 1f)); row.addView(text(v?.let { "$it/5" } ?: "—", 12f), LinearLayout.LayoutParams(dp(38), -2)); graph.addView(row) }; val valid = values.mapNotNull { it.second }; val avg = if (valid.isEmpty()) "Belum ada data mood" else "Rata-rata mood: ${String.format(Locale.US, "%.1f", valid.average())}/5 · ${valid.size} hari tercatat"; graph.addView(text(avg, 13f, true, green)) }
        drawMood(7); period.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { drawMood(if (position == 0) 7 else 30) } }; moodCard.addView(button("Catat / ubah Mood hari ini") { showMoodDialog(false) }); moodCard.addView(button("Riwayat mood & catatan") { showMoodHistory() }); content.addView(moodCard)
        content.addView(text("Riwayat tugas", 16f, true)); TaskStore.historySummary(this).forEach { content.addView(text(it, 13f)) }
    }
    private fun showMoodHistory() {
        val root = WorkoutStore.moods(this); val keys = mutableListOf<String>(); val it = root.keys(); while (it.hasNext()) keys.add(it.next()); keys.sortDescending()
        val msg = if (keys.isEmpty()) "Belum ada catatan mood." else keys.take(30).joinToString("\n\n") { d -> val o = root.optJSONObject(d); "$d · ${o?.optInt("value") ?: "—"}/5\n${o?.optString("note").orEmpty()}" }
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Riwayat Mood").setMessage(msg).setPositiveButton("Tutup", null).show()
    }
    private fun maybePromptMood() {
        val today = TaskStore.today(); if (prefs().getString("mood_prompted_$today", null) == "yes") return
        val sessions = WorkoutStore.sessionsForDate(this); val allTasksDone = tasks.all { done.contains(it.id) }; val allWorkoutsDone = sessions.all { WorkoutStore.isDone(this, it.id) }
        if (allTasksDone && allWorkoutsDone && (tasks.isNotEmpty() || sessions.isNotEmpty())) {
            prefs().edit().putString("mood_prompted_$today", "yes").apply()
            if (WorkoutStore.mood(this, today) == null) AlertDialog.Builder(this, R.style.RillDialog).setTitle("Bagaimana mood kamu sekarang?").setMessage("Checklist harianmu selesai. Luangkan sebentar untuk mencatat perasaanmu, jika mau.").setPositiveButton("Catat Mood") { _, _ -> showMoodDialog(false) }.setNegativeButton("Nanti saja", null).show()
        }
    }
    private fun showMoodDialog(fromStats: Boolean) {
        val today = TaskStore.today(); val previous = WorkoutStore.mood(this, today); val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(4), dp(18), dp(4)) }
        box.addView(text("Pilih mood yang paling menggambarkan keadaanmu sekarang.", 14f)); val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("1 · Buruk", "2 · Kurang baik", "3 · Biasa", "4 · Baik", "5 · Sangat baik")); setSelection(((previous?.optInt("value", 3) ?: 3) - 1).coerceIn(0, 4)) }; box.addView(spinner)
        val note = EditText(this).apply { hint = "Catatan opsional"; minLines = 2; setText(previous?.optString("note", "") ?: "") }; box.addView(note)
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Mood Harian").setView(box).setPositiveButton("Simpan") { _, _ -> WorkoutStore.saveMood(this, today, spinner.selectedItemPosition + 1, note.text.toString()); prefs().edit().putString("mood_prompted_$today", "yes").apply(); Toast.makeText(this, "Mood tersimpan di perangkat.", Toast.LENGTH_SHORT).show(); render() }.setNegativeButton("Lewati", null).show()
    }
    private fun showReviewDialog() {
        val input = EditText(this).apply { hint = "Apa yang berhasil hari ini? Apa yang mau diperbaiki?" }
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Evaluasi hari ini").setView(input).setPositiveButton("Simpan") { _, _ -> prefs().edit().putString("review_${TaskStore.today()}", input.text.toString()).apply(); Toast.makeText(this, "Evaluasi tersimpan.", Toast.LENGTH_SHORT).show() }.setNegativeButton("Batal", null).show()
    }
    private fun createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) { val channel = android.app.NotificationChannel("rill_reminders", "Pengingat RilHabit", android.app.NotificationManager.IMPORTANCE_DEFAULT); getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel) }
    }
}
