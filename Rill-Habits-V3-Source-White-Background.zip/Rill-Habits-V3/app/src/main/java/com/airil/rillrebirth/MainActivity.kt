package com.airil.rillrebirth

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.WHITE
    private val ink = Color.rgb(35, 48, 65)
    private val green = Color.rgb(46, 125, 104)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selectedTab = "Home"
    private var tasks = mutableListOf<RillTask>()
    private var done = mutableSetOf<Int>()
    private var selectedWorkoutId = -1L
    private var timerDuration = 90L
    private var timerRemaining = 90L
    private var timerRunning = false
    private var timerEndAt = 0L
    private var timerMode = "Istirahat"
    private var timerLabel: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val timerTick = object : Runnable {
        override fun run() {
            if (!timerRunning) return
            timerRemaining = ((timerEndAt - SystemClock.elapsedRealtime() + 999) / 1000).coerceAtLeast(0)
            timerLabel?.text = formatTime(timerRemaining)
            if (timerRemaining <= 0) {
                timerRunning = false
                try { val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 75); tone.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 500) } catch (_: Exception) {}
                Toast.makeText(this@MainActivity, "Waktu timer selesai!", Toast.LENGTH_LONG).show()
            } else handler.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tasks = TaskStore.load(this)
        done = TaskStore.doneToday(this)
        createNotificationChannel()
        render()
        ReminderScheduler.scheduleAll(this)
        maybePromptMood()
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) { tasks = TaskStore.load(this); done = TaskStore.doneToday(this); render(); maybePromptMood() } }
    override fun onDestroy() { handler.removeCallbacks(timerTick); super.onDestroy() }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("rill_data", Context.MODE_PRIVATE)
    private fun text(value: String, size: Float, bold: Boolean = false, color: Int = ink): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(dp(2), dp(4), dp(2), dp(4))
    }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)); setBackgroundColor(Color.WHITE)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(5), 0, dp(5)); layoutParams = lp
    }
    private fun section(title: String) { content.addView(text(title, 15f, true)) }
    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(10)); setBackgroundColor(Color.WHITE) }
        header.addView(text("RilHabit", 24f, true, green)); header.addView(text("PERSONAL OS · Pelan-pelan, konsisten.", 12f, false, Color.DKGRAY)); root.addView(header)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(2), dp(3), dp(2), dp(3)); setBackgroundColor(Color.WHITE) }
        listOf("Home", "Checklist", "Workout", "Jadwal", "Statistik").forEach { tab ->
            nav.addView(Button(this).apply { text = tab; textSize = 10f; isAllCaps = false; setPadding(0, 0, 0, 0); setTextColor(if (selectedTab == tab) green else ink); setOnClickListener { selectedTab = tab; render() } }, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        root.addView(nav)
        val scroll = ScrollView(this); content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(18)) }; scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        when (selectedTab) { "Home" -> showHome(); "Checklist" -> showChecklist(); "Workout" -> showWorkout(); "Jadwal" -> showSchedule(); "Statistik" -> showStats() }
        setContentView(root)
    }

    private fun showHome() {
        val currentXp = TaskStore.xpFor(this, done) + WorkoutStore.workoutXpToday(this); val totalXp = TaskStore.totalXp(this) + WorkoutStore.totalWorkoutXp(this); val level = totalXp / 100 + 1
        val progress = if (tasks.isEmpty()) 0 else (done.size * 100 / tasks.size)
        val c = card(); c.addView(text("Hari ini", 17f, true)); c.addView(text("$progress% selesai", 28f, true, green)); c.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; this.progress = progress }, LinearLayout.LayoutParams(-1, dp(10)))
        c.addView(text("${done.size} dari ${tasks.size} tugas · +$currentXp EXP hari ini", 13f)); c.addView(text("Level $level · $totalXp EXP terkumpul", 13f, true)); content.addView(c)
        val sessions = WorkoutStore.sessionsForDate(this); val finished = sessions.count { WorkoutStore.isDone(this, it.id) }
        val w = card(); w.addView(text("Workout hari ini", 16f, true)); w.addView(text(if (sessions.isEmpty()) "Tidak ada workout terjadwal hari ini" else "$finished dari ${sessions.size} sesi selesai", 14f)); w.addView(button("Buka Workout") { selectedTab = "Workout"; render() }); content.addView(w)
        val note = card(); note.addView(text("Daily Note", 16f, true)); val edit = EditText(this).apply { hint = "Tulis catatan singkat untuk hari ini…"; minLines = 2; gravity = Gravity.TOP; setText(prefs().getString("daily_note_${TaskStore.today()}", "") ?: "") }; note.addView(edit); note.addView(button("Simpan catatan") { prefs().edit().putString("daily_note_${TaskStore.today()}", edit.text.toString()).apply(); Toast.makeText(this, "Daily Note tersimpan.", Toast.LENGTH_SHORT).show() }); content.addView(note)
        val mood = WorkoutStore.mood(this, TaskStore.today()); val m = card(); m.addView(text("Mood hari ini", 16f, true)); m.addView(text(if (mood == null) "Belum dicatat" else "${mood.optInt("value")}/5 · ${mood.optString("note")}", 14f)); m.addView(button(if (mood == null) "Catat Mood" else "Ubah Mood") { showMoodDialog(false) }); content.addView(m)
        content.addView(button("Buka checklist harian") { selectedTab = "Checklist"; render() })
    }

    private fun showChecklist() {
        val sessions = WorkoutStore.sessionsForDate(this)
        val total = tasks.size + sessions.size; val completed = done.size + sessions.count { WorkoutStore.isDone(this, it.id) }
        val summary = card(); summary.addView(text("Checklist harian", 18f, true)); summary.addView(text("$completed dari $total item selesai", 14f)); content.addView(summary)
        section("TUGAS HARIAN")
        tasks.sortedBy { it.time }.forEach { task ->
            val row = card(); val check = CheckBox(this).apply { text = "${task.name}\n${task.time} · ${task.category} · ${task.xp} EXP"; textSize = 14f; isChecked = done.contains(task.id); setOnCheckedChangeListener { _, checked -> if (checked) done.add(task.id) else done.remove(task.id); TaskStore.saveDone(this@MainActivity, done); render(); maybePromptMood() } }; row.addView(check); content.addView(row)
        }
        section("WORKOUT TERJADWAL")
        if (sessions.isEmpty()) content.addView(text("Belum ada workout untuk hari ini. Kamu bisa menambahkannya dari menu Workout.", 13f, false, Color.DKGRAY))
        sessions.forEach { session ->
            val row = card(); val check = CheckBox(this).apply { text = "${session.name}\n${session.time} · ${session.durationMinutes} menit"; isChecked = WorkoutStore.isDone(this@MainActivity, session.id); setOnCheckedChangeListener { _, checked -> WorkoutStore.setDone(this@MainActivity, session.id, checked); render(); maybePromptMood() } }; row.addView(check); row.addView(button("Detail sesi") { selectedWorkoutId = session.id; selectedTab = "Workout"; render() }); content.addView(row)
        }
        content.addView(button("Evaluasi malam") { showReviewDialog() })
        content.addView(button("Catat Mood sekarang") { showMoodDialog(false) })
    }

    private fun showWorkout() {
        val sessions = WorkoutStore.sessionsForDate(this)
        val dash = card(); dash.addView(text("Sesi hari ini", 17f, true))
        if (sessions.isEmpty()) dash.addView(text("Tidak ada workout terjadwal hari ini", 14f))
        sessions.forEach { s -> dash.addView(text("${s.time} · ${s.name} · ${s.durationMinutes} menit${if (WorkoutStore.isDone(this, s.id)) " · SELESAI" else ""}", 14f, true)); dash.addView(button("Lihat detail sesi") { selectedWorkoutId = s.id; showWorkoutDetail(s.id) }) }
        dash.addView(text("Workout Streak: ${WorkoutStore.currentStreak(this)} hari", 16f, true, green)); dash.addView(text("Rekor terbaik: ${WorkoutStore.bestStreak(this)} hari", 13f)); content.addView(dash)
        val weekly = WorkoutStore.completedIds(this).size // daily count is separate from streak
        val weekCount = (-6..0).count { WorkoutStore.workoutDayActive(this, WorkoutStore.date(it)) }
        val target = prefs().getInt("weekly_workout_goal", 4)
        val goal = card(); goal.addView(text("Target mingguan", 16f, true)); goal.addView(text("$weekCount/$target hari aktif minggu ini", 14f)); goal.addView(button("Ubah target mingguan") { val e = EditText(this).apply { inputType = 2; setText(target.toString()); hint = "Target hari per minggu" }; AlertDialog.Builder(this).setTitle("Target mingguan").setView(e).setPositiveButton("Simpan") { _, _ -> prefs().edit().putInt("weekly_workout_goal", (e.text.toString().toIntOrNull() ?: 4).coerceIn(1, 7)).apply(); render() }.setNegativeButton("Batal", null).show() }); content.addView(goal)
        content.addView(button("+ Buat workout") { editWorkout(null) })
        content.addView(button("Program latihan siap pakai") { showPrograms() })
        content.addView(button("Timer Workout") { showTimer() })
        section("PROGRAM & JADWAL SAYA")
        WorkoutStore.load(this).forEach { s ->
            val c = card(); c.addView(text(s.name, 15f, true)); c.addView(text("${if (s.active) "Aktif" else "Dijeda"} · ${s.time} · ${s.durationMinutes} menit", 12f, false, Color.DKGRAY)); c.addView(button("Buka sesi / checklist gerakan") { selectedWorkoutId = s.id; showWorkoutDetail(s.id) }); c.addView(button("Edit workout") { editWorkout(s) }); c.addView(button(if (s.active) "Jeda program" else "Aktifkan program") { s.active = !s.active; WorkoutStore.save(this, WorkoutStore.load(this).map { if (it.id == s.id) s else it }); ReminderScheduler.scheduleAll(this); render() }); content.addView(c)
        }
    }

    private fun showWorkoutDetail(id: Long) {
        val session = WorkoutStore.load(this).find { it.id == id } ?: run { render(); return }
        content.removeAllViews()
        val c = card(); c.addView(text(session.name, 20f, true)); c.addView(text("${session.time} · ${session.durationMinutes} menit", 13f)); if (session.notes.isNotBlank()) c.addView(text(session.notes, 13f)); c.addView(text("Centang setiap gerakan yang sudah selesai. Progres tersimpan otomatis.", 12f, false, Color.DKGRAY))
        val checked = WorkoutStore.exerciseChecks(this, id)
        session.exercises.forEachIndexed { index, exercise ->
            val cb = CheckBox(this).apply { text = "${exercise.name}\n${exercise.sets} set · ${exercise.reps} repetisi"; isChecked = checked.contains(index); setOnCheckedChangeListener { _, value -> val next = WorkoutStore.exerciseChecks(this@MainActivity, id); if (value) next.add(index) else next.remove(index); WorkoutStore.saveExerciseChecks(this@MainActivity, id, next); } }; c.addView(cb)
        }
        c.addView(button("Timer istirahat") { timerMode = "Istirahat"; showTimer() }); c.addView(button("Timer bebas") { timerMode = "Bebas"; showTimer() }); c.addView(button(if (WorkoutStore.isDone(this, id)) "Batalkan status selesai" else "Selesaikan Workout") {
            val wasDone = WorkoutStore.isDone(this, id); WorkoutStore.setDone(this, id, !wasDone)
            if (!wasDone) { val set = WorkoutStore.completedIds(this); Toast.makeText(this, "Workout selesai! Streak: ${WorkoutStore.currentStreak(this)} hari", Toast.LENGTH_SHORT).show() }
            render(); maybePromptMood()
        }); c.addView(button("Kembali ke Workout") { render() }); content.addView(c)
    }

    private fun showPrograms() {
        val options = arrayOf("Beginner Movement", "Bodyweight Basics", "Walking & Jogging")
        AlertDialog.Builder(this).setTitle("Pilih program latihan").setItems(options) { _, which ->
            val template = when (which) {
                0 -> listOf(WorkoutExercise("Jalan di tempat", 2, "60 detik"), WorkoutExercise("Squat", 2, "8–10"), WorkoutExercise("Peregangan ringan", 2, "20 detik"))
                1 -> listOf(WorkoutExercise("Squat", 3, "8–12"), WorkoutExercise("Wall Push Up", 3, "8–12"), WorkoutExercise("Glute Bridge", 3, "10–12"), WorkoutExercise("Plank", 2, "15–30 detik"))
                else -> listOf(WorkoutExercise("Jalan santai", 1, "10 menit"), WorkoutExercise("Jalan cepat / jogging ringan", 1, "10–20 menit"), WorkoutExercise("Pendinginan", 1, "5 menit"))
            }
            val name = options[which]; val s = WorkoutSession(System.currentTimeMillis(), name, "18:00", 25, mutableSetOf(Calendar.MONDAY, Calendar.WEDNESDAY, Calendar.FRIDAY), "", "Program siap pakai; sesuaikan dengan kemampuanmu.", false, true, template.toMutableList()); editWorkout(s)
        }.setNegativeButton("Batal", null).show()
    }

    private fun editWorkout(existing: WorkoutSession?) {
        val s = existing ?: WorkoutSession(System.currentTimeMillis(), "", "18:00", 30, mutableSetOf(Calendar.MONDAY, Calendar.WEDNESDAY, Calendar.FRIDAY), "", "", false, true, mutableListOf(WorkoutExercise("Gerakan 1", 3, "8–12")))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(4), dp(18), dp(4)) }
        val name = EditText(this).apply { hint = "Nama workout"; setText(s.name) }
        val time = EditText(this).apply { hint = "Waktu HH:MM"; setText(s.time) }
        val duration = EditText(this).apply { hint = "Durasi menit"; inputType = 2; setText(s.durationMinutes.toString()) }
        val days = EditText(this).apply { hint = "Hari berulang: Sen, Rab, Jum (kosong = sekali)"; setText(if (s.days.isEmpty()) "" else s.days.sorted().joinToString(",") { dayShort(it) }) }
        val date = EditText(this).apply { hint = "Tanggal sekali jalan YYYY-MM-DD (opsional)"; setText(s.oneOffDate) }
        val notes = EditText(this).apply { hint = "Catatan workout (opsional)"; setText(s.notes); minLines = 2 }
        val exercises = EditText(this).apply { hint = "Gerakan, satu per baris. Contoh: Squat | 3 set | 8–12"; setText(s.exercises.joinToString("\n") { "${it.name} | ${it.sets} set | ${it.reps}" }); minLines = 4 }
        val reminder = CheckBox(this).apply { text = "Pengingat harian"; isChecked = s.reminder }
        listOf(name, time, duration, days, date, notes, exercises, reminder).forEach { box.addView(it) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "Buat workout" else "Edit workout").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Simpan") { _, _ ->
            val t = time.text.toString().trim(); if (name.text.isNullOrBlank() || !Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(t)) { Toast.makeText(this, "Isi nama dan waktu HH:MM yang valid.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
            s.name = name.text.toString().trim(); s.time = String.format(Locale.US, "%02d:%02d", t.substringBefore(":").toInt(), t.substringAfter(":").toInt()); s.durationMinutes = (duration.text.toString().toIntOrNull() ?: 30).coerceIn(1, 600); s.oneOffDate = date.text.toString().trim(); s.notes = notes.text.toString(); s.reminder = reminder.isChecked
            val dayText = days.text.toString().trim(); s.days = if (dayText.isBlank()) mutableSetOf() else parseDays(dayText)
            s.exercises = exercises.text.toString().lines().mapNotNull { line -> val parts = line.split("|").map { it.trim() }; if (parts[0].isBlank()) null else WorkoutExercise(parts[0], parts.getOrNull(1)?.filter { it.isDigit() }?.toIntOrNull() ?: 3, parts.getOrNull(2) ?: "8–12") }.toMutableList()
            val all = WorkoutStore.load(this); if (existing == null) all.add(s) else { val idx = all.indexOfFirst { it.id == s.id }; if (idx >= 0) all[idx] = s else all.add(s) }; WorkoutStore.save(this, all); ReminderScheduler.scheduleAll(this); render()
        }.setNeutralButton(if (existing == null) "Batal" else "Arsipkan") { _, _ -> if (existing != null) { val all = WorkoutStore.load(this); all.find { it.id == s.id }?.active = false; WorkoutStore.save(this, all); render() } }.setNegativeButton("Tutup", null).show()
    }

    private fun parseDays(raw: String): MutableSet<Int> {
        val out = mutableSetOf<Int>(); raw.split(",", " ", ";").map { it.trim().lowercase(Locale.ROOT) }.forEach { when (it) { "min", "minggu", "sun" -> out.add(Calendar.SUNDAY); "sen", "senin", "mon" -> out.add(Calendar.MONDAY); "sel", "selasa", "tue" -> out.add(Calendar.TUESDAY); "rab", "rabu", "wed" -> out.add(Calendar.WEDNESDAY); "kam", "kamis", "thu" -> out.add(Calendar.THURSDAY); "jum", "jumat", "jum'at", "fri" -> out.add(Calendar.FRIDAY); "sab", "sabtu", "sat" -> out.add(Calendar.SATURDAY) } }; return out
    }
    private fun dayShort(d: Int) = when (d) { Calendar.SUNDAY -> "Min"; Calendar.MONDAY -> "Sen"; Calendar.TUESDAY -> "Sel"; Calendar.WEDNESDAY -> "Rab"; Calendar.THURSDAY -> "Kam"; Calendar.FRIDAY -> "Jum"; else -> "Sab" }

    private fun showTimer() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(22), dp(12), dp(22), dp(12)) }
        val label = text(formatTime(timerRemaining), 38f, true, green).apply { gravity = Gravity.CENTER }; timerLabel = label; box.addView(label)
        box.addView(text("Mode: $timerMode", 14f, false, Color.DKGRAY).apply { gravity = Gravity.CENTER })
        val duration = EditText(this).apply { hint = "Durasi dalam detik"; inputType = 2; setText(timerDuration.toString()) }; box.addView(duration)
        box.addView(button("Atur durasi") { val sec = duration.text.toString().toLongOrNull()?.coerceIn(1, 86400) ?: timerDuration; timerDuration = sec; timerRemaining = sec; timerRunning = false; handler.removeCallbacks(timerTick); label.text = formatTime(sec) })
        box.addView(button(if (timerRunning) "Jeda" else "Mulai / Lanjutkan") { if (timerRunning) { timerRunning = false; handler.removeCallbacks(timerTick) } else { if (timerRemaining <= 0) timerRemaining = timerDuration; timerRunning = true; timerEndAt = SystemClock.elapsedRealtime() + timerRemaining * 1000; handler.removeCallbacks(timerTick); handler.post(timerTick) } })
        box.addView(button("Reset") { timerRunning = false; handler.removeCallbacks(timerTick); timerRemaining = timerDuration; label.text = formatTime(timerRemaining) })
        val mode = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Istirahat antar-gerakan", "Timer bebas")); setSelection(if (timerMode == "Bebas") 1 else 0); onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { timerMode = if (position == 1) "Bebas" else "Istirahat" } } }; box.addView(mode)
        AlertDialog.Builder(this).setTitle("Workout Timer").setView(box).setPositiveButton("Selesai", null).show()
    }
    private fun formatTime(seconds: Long): String = String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)

    private fun showSchedule() {
        content.addView(text("Jadwal & Pengingat", 18f, true)); content.addView(text("Tugas dan workout disimpan di perangkat. Pengingat bergantung pada izin Android/MIUI.", 13f))
        content.addView(button("Tambah kegiatan checklist") { editTask(null) })
        content.addView(button("Pengingat tugas: ${if (prefs().getBoolean("reminders_enabled", true)) "Aktif" else "Nonaktif"}") { val on = !prefs().getBoolean("reminders_enabled", true); prefs().edit().putBoolean("reminders_enabled", on).apply(); ReminderScheduler.scheduleAll(this); render() })
        section("KEGIATAN")
        tasks.forEach { t -> content.addView(button("${t.time} · ${t.name} ✎") { editTask(t) }) }
        section("WORKOUT")
        content.addView(button("Tambah / edit jadwal workout") { selectedTab = "Workout"; render() })
        WorkoutStore.load(this).forEach { s -> content.addView(text("${s.name} · ${if (s.oneOffDate.isNotBlank()) s.oneOffDate else s.days.sorted().joinToString(", ") { dayShort(it) }} · ${if (s.active) "Aktif" else "Dijeda/arsip"}", 13f)) }
    }
    private fun editTask(existing: RillTask?) {
        val task = existing ?: RillTask((tasks.maxOfOrNull { it.id } ?: 0) + 1, "", "18:00", "Umum", 10, false)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
        val name = EditText(this).apply { hint = "Nama kegiatan"; setText(task.name) }; val time = EditText(this).apply { hint = "HH:MM"; setText(task.time) }; val category = EditText(this).apply { hint = "Kategori"; setText(task.category) }; val xp = EditText(this).apply { hint = "EXP (angka)"; setText(task.xp.toString()); inputType = 2 }; val reminder = CheckBox(this).apply { text = "Aktifkan pengingat harian"; isChecked = task.reminderEnabled }
        box.addView(name); box.addView(time); box.addView(category); box.addView(xp); box.addView(reminder)
        AlertDialog.Builder(this).setTitle(if (existing == null) "Tambah kegiatan" else "Edit kegiatan").setView(box).setPositiveButton("Simpan") { _, _ ->
            val tv = time.text.toString().trim(); val valid = Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(tv); if (name.text.isNullOrBlank() || !valid) { Toast.makeText(this, "Isi nama dan waktu HH:MM yang valid.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
            task.name = name.text.toString().trim(); task.time = String.format(Locale.US, "%02d:%02d", tv.substringBefore(":").toInt(), tv.substringAfter(":").toInt()); task.category = category.text.toString().ifBlank { "Umum" }; task.xp = (xp.text.toString().toIntOrNull() ?: 10).coerceIn(0, 500); task.reminderEnabled = reminder.isChecked
            if (existing == null) tasks.add(task); TaskStore.save(this, tasks); ReminderScheduler.scheduleAll(this); render()
        }.setNeutralButton(if (existing != null) "Hapus" else "Batal") { _, _ -> if (existing != null) { tasks.removeAll { it.id == task.id }; done.remove(task.id); TaskStore.save(this, tasks); TaskStore.saveDone(this, done); ReminderScheduler.scheduleAll(this); render() } }.setNegativeButton("Tutup", null).show()
    }

    private fun showStats() {
        val c = card(); c.addView(text("Statistik Workout", 18f, true)); val sessions = WorkoutStore.load(this); val completedCount = sessions.sumOf { s -> (-29..0).count { WorkoutStore.isDone(this, s.id, WorkoutStore.date(it)) } }; c.addView(text("Sesi selesai dalam 30 hari terakhir: $completedCount", 14f)); c.addView(text("Streak saat ini: ${WorkoutStore.currentStreak(this)} hari · Rekor: ${WorkoutStore.bestStreak(this)} hari", 14f)); c.addView(text("Target mingguan: ${prefs().getInt("weekly_workout_goal", 4)} hari", 14f)); content.addView(c)
        val history = card(); history.addView(text("Riwayat workout · 7 hari", 16f, true)); for (off in -6..0) { val d = WorkoutStore.date(off); val count = WorkoutStore.completedIds(this, d).size; history.addView(text("$d · $count sesi selesai", 13f)) }; content.addView(history)
        val moods = WorkoutStore.moods(this); val moodCard = card(); moodCard.addView(text("Kurva Mood", 18f, true)); val period = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("7 hari", "1 bulan")) }; moodCard.addView(period)
        val graph = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; moodCard.addView(graph)
        fun drawMood(days: Int) { graph.removeAllViews(); val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US); val cal = Calendar.getInstance(); val values = mutableListOf<Pair<String, Int?>>(); for (off in days - 1 downTo 0) { cal.time = Date(); cal.add(Calendar.DAY_OF_YEAR, -off); val d = fmt.format(cal.time); values.add(d to moods.optJSONObject(d)?.optInt("value")) }; values.forEach { (d, v) -> val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }; row.addView(text(d.substring(5), 11f, false, Color.DKGRAY), LinearLayout.LayoutParams(dp(48), -2)); val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 5; progress = v ?: 0 }; row.addView(bar, LinearLayout.LayoutParams(0, dp(12), 1f)); row.addView(text(v?.let { "$it/5" } ?: "—", 12f), LinearLayout.LayoutParams(dp(38), -2)); graph.addView(row) }; val valid = values.mapNotNull { it.second }; val avg = if (valid.isEmpty()) "Belum ada data mood" else "Rata-rata mood: ${String.format(Locale.US, "%.1f", valid.average())}/5 · ${valid.size} hari tercatat"; graph.addView(text(avg, 13f, true, green)) }
        drawMood(7); period.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}; override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { drawMood(if (position == 0) 7 else 30) } }; moodCard.addView(button("Catat / ubah Mood hari ini") { showMoodDialog(false) }); moodCard.addView(button("Riwayat mood & catatan") { showMoodHistory() }); content.addView(moodCard)
        content.addView(text("Riwayat tugas", 16f, true)); TaskStore.historySummary(this).forEach { content.addView(text(it, 13f)) }
    }
    private fun showMoodHistory() {
        val root = WorkoutStore.moods(this); val keys = mutableListOf<String>(); val it = root.keys(); while (it.hasNext()) keys.add(it.next()); keys.sortDescending()
        val msg = if (keys.isEmpty()) "Belum ada catatan mood." else keys.take(30).joinToString("\n\n") { d -> val o = root.optJSONObject(d); "$d · ${o?.optInt("value") ?: "—"}/5\n${o?.optString("note").orEmpty()}" }
        AlertDialog.Builder(this).setTitle("Riwayat Mood").setMessage(msg).setPositiveButton("Tutup", null).show()
    }
    private fun maybePromptMood() {
        val today = TaskStore.today(); if (prefs().getString("mood_prompted_$today", null) == "yes") return
        val sessions = WorkoutStore.sessionsForDate(this); val allTasksDone = tasks.all { done.contains(it.id) }; val allWorkoutsDone = sessions.all { WorkoutStore.isDone(this, it.id) }
        if (allTasksDone && allWorkoutsDone && (tasks.isNotEmpty() || sessions.isNotEmpty())) {
            prefs().edit().putString("mood_prompted_$today", "yes").apply()
            if (WorkoutStore.mood(this, today) == null) AlertDialog.Builder(this).setTitle("Bagaimana mood kamu sekarang?").setMessage("Checklist harianmu selesai. Luangkan sebentar untuk mencatat perasaanmu, jika mau.").setPositiveButton("Catat Mood") { _, _ -> showMoodDialog(false) }.setNegativeButton("Nanti saja", null).show()
        }
    }
    private fun showMoodDialog(fromStats: Boolean) {
        val today = TaskStore.today(); val previous = WorkoutStore.mood(this, today); val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(4), dp(18), dp(4)) }
        box.addView(text("Pilih mood yang paling menggambarkan keadaanmu sekarang.", 14f)); val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("1 · Buruk", "2 · Kurang baik", "3 · Biasa", "4 · Baik", "5 · Sangat baik")); setSelection(((previous?.optInt("value", 3) ?: 3) - 1).coerceIn(0, 4)) }; box.addView(spinner)
        val note = EditText(this).apply { hint = "Catatan opsional"; minLines = 2; setText(previous?.optString("note", "") ?: "") }; box.addView(note)
        AlertDialog.Builder(this).setTitle("Mood Harian").setView(box).setPositiveButton("Simpan") { _, _ -> WorkoutStore.saveMood(this, today, spinner.selectedItemPosition + 1, note.text.toString()); prefs().edit().putString("mood_prompted_$today", "yes").apply(); Toast.makeText(this, "Mood tersimpan di perangkat.", Toast.LENGTH_SHORT).show(); render() }.setNegativeButton("Lewati", null).show()
    }
    private fun showReviewDialog() {
        val input = EditText(this).apply { hint = "Apa yang berhasil hari ini? Apa yang mau diperbaiki?" }
        AlertDialog.Builder(this).setTitle("Evaluasi hari ini").setView(input).setPositiveButton("Simpan") { _, _ -> prefs().edit().putString("review_${TaskStore.today()}", input.text.toString()).apply(); Toast.makeText(this, "Evaluasi tersimpan.", Toast.LENGTH_SHORT).show() }.setNegativeButton("Batal", null).show()
    }
    private fun createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) { val channel = android.app.NotificationChannel("rill_reminders", "Pengingat RilHabit", android.app.NotificationManager.IMPORTANCE_DEFAULT); getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel) }
    }
}
