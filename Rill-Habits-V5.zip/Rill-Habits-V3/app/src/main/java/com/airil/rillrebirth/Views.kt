package com.airil.rillrebirth

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

internal fun tint(color: Int, amount: Float): Int {
    val r = Color.red(color)
    val g = Color.green(color)
    val b = Color.blue(color)
    return Color.rgb((r + (255 - r) * amount).toInt(), (g + (255 - g) * amount).toInt(), (b + (255 - b) * amount).toInt())
}

/** Donut progress ring. Each segment owns an arc sized by its item count and filled by its done count. */
class RingView(context: Context) : View(context) {
    class Seg(val color: Int, val total: Int, val done: Int)

    var segs: List<Seg> = emptyList()
    var progress = 1f
    var centerText = ""
    var centerSub = ""
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rect = RectF()

    fun animateIn(ms: Long = 500) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = ms
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { v ->
            progress = v.animatedValue as Float
            invalidate()
        }
        a.start()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = min(w, h)
        val stroke = s * 0.12f
        val cx = w / 2f
        val cy = h / 2f
        val r = (s - stroke) / 2f
        rect.set(cx - r, cy - r, cx + r, cy + r)
        arcPaint.strokeWidth = stroke
        val active = segs.filter { it.total > 0 }
        val sum = active.sumOf { it.total }
        if (sum == 0) {
            arcPaint.color = Color.parseColor("#ECECF1")
            canvas.drawArc(rect, 0f, 360f, false, arcPaint)
        } else if (active.size == 1) {
            val seg = active[0]
            arcPaint.color = tint(seg.color, 0.82f)
            canvas.drawArc(rect, 0f, 360f, false, arcPaint)
            val frac = seg.done.toFloat() / seg.total * progress
            if (frac > 0f) {
                arcPaint.color = seg.color
                canvas.drawArc(rect, -90f, max(360f * frac, 0.1f), false, arcPaint)
            }
        } else {
            val gap = 10f
            val avail = 360f - gap * active.size
            val capDeg = Math.toDegrees((stroke / 2f / r).toDouble()).toFloat()
            var start = -90f
            for (seg in active) {
                val sweep = avail * seg.total / sum
                val a0 = start + gap / 2f + capDeg
                val eff = max(sweep - 2f * capDeg, 1f)
                arcPaint.color = tint(seg.color, 0.82f)
                canvas.drawArc(rect, a0, eff, false, arcPaint)
                val frac = seg.done.toFloat() / seg.total * progress
                if (frac > 0f) {
                    arcPaint.color = seg.color
                    canvas.drawArc(rect, a0, max(eff * frac, 0.1f), false, arcPaint)
                }
                start += sweep + gap
            }
        }
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.color = Color.parseColor("#1C1C1E")
        textPaint.textSize = s * 0.24f
        val fm = textPaint.fontMetrics
        val shift = if (centerSub.isNotEmpty()) s * 0.05f else 0f
        canvas.drawText(centerText, cx, cy - (fm.ascent + fm.descent) / 2f - shift, textPaint)
        if (centerSub.isNotEmpty()) {
            textPaint.typeface = Typeface.DEFAULT
            textPaint.color = Color.parseColor("#8E8E93")
            textPaint.textSize = s * 0.09f
            canvas.drawText(centerSub, cx, cy + s * 0.17f, textPaint)
        }
    }
}

/** Smooth mood curve (values 1..5, null = no data). */
class LineChartView(context: Context) : View(context) {
    var values: List<Float?> = emptyList()
    var xLabels: List<String> = emptyList()
    var details: List<String> = emptyList()
    var progress = 1f
    private var selected = -1
    private val d = context.resources.displayMetrics.density
    private val grid = Paint().apply { color = Color.parseColor("#ECECF1"); strokeWidth = d }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d; color = Color.parseColor("#2F6F4F"); strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#8E8E93"); textSize = 10f * d; textAlign = Paint.Align.CENTER }
    private val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 13f * d; textAlign = Paint.Align.CENTER }
    private val tipBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1C1C1E") }
    private val tipText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 11f * d; textAlign = Paint.Align.CENTER }
    private val emojis = arrayOf("😣", "😕", "😐", "🙂", "🤩")

    fun setData(v: List<Float?>, labels: List<String>, det: List<String>) {
        values = v
        xLabels = labels
        details = det
        selected = -1
        invalidate()
    }

    fun animateIn(ms: Long = 500) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = ms
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { v ->
            progress = v.animatedValue as Float
            invalidate()
        }
        a.start()
    }

    private val padL get() = 30f * d
    private val padR get() = 14f * d
    private val padT get() = 16f * d
    private val padB get() = 24f * d

    private fun xAt(i: Int): Float {
        val n = values.size
        val plotW = width - padL - padR
        return if (n <= 1) padL + plotW / 2f else padL + plotW * i / (n - 1)
    }

    private fun yAt(v: Float): Float {
        val plotH = height - padT - padB
        return padT + plotH * (1f - (v - 1f) / 4f)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (lv in 1..5) {
            val y = yAt(lv.toFloat())
            canvas.drawLine(padL, y, w - padR, y, grid)
            val fm = emojiPaint.fontMetrics
            canvas.drawText(emojis[lv - 1], padL / 2f - 2f * d, y - (fm.ascent + fm.descent) / 2f, emojiPaint)
        }
        val pts = ArrayList<PointF>()
        val idx = ArrayList<Int>()
        for (i in values.indices) {
            val v = values[i]
            if (v != null) {
                pts.add(PointF(xAt(i), yAt(v)))
                idx.add(i)
            }
        }
        for (i in xLabels.indices) {
            val l = xLabels[i]
            if (l.isNotEmpty()) canvas.drawText(l, xAt(i), h - 6f * d, labelPaint)
        }
        if (pts.isEmpty()) {
            labelPaint.textSize = 12f * d
            canvas.drawText("Belum ada data mood", w / 2f, h / 2f, labelPaint)
            labelPaint.textSize = 10f * d
            return
        }
        canvas.save()
        canvas.clipRect(0f, 0f, padL + (w - padL) * progress, h)
        if (pts.size >= 2) {
            val path = Path()
            path.moveTo(pts[0].x, pts[0].y)
            for (k in 1 until pts.size) {
                val p0 = pts[k - 1]
                val p1 = pts[k]
                val mx = (p0.x + p1.x) / 2f
                path.cubicTo(mx, p0.y, mx, p1.y, p1.x, p1.y)
            }
            val fill = Path(path)
            fill.lineTo(pts[pts.size - 1].x, h - padB)
            fill.lineTo(pts[0].x, h - padB)
            fill.close()
            fillPaint.shader = LinearGradient(0f, padT, 0f, h - padB, Color.argb(80, 47, 111, 79), Color.argb(0, 47, 111, 79), Shader.TileMode.CLAMP)
            canvas.drawPath(fill, fillPaint)
            canvas.drawPath(path, linePaint)
        }
        for (k in pts.indices) {
            val p = pts[k]
            val isSel = idx[k] == selected
            dotPaint.style = Paint.Style.FILL
            dotPaint.color = Color.WHITE
            canvas.drawCircle(p.x, p.y, (if (isSel) 6f else 4.5f) * d, dotPaint)
            dotPaint.style = Paint.Style.STROKE
            dotPaint.strokeWidth = 2.5f * d
            dotPaint.color = Color.parseColor("#2F6F4F")
            canvas.drawCircle(p.x, p.y, (if (isSel) 6f else 4.5f) * d, dotPaint)
        }
        canvas.restore()
        val sk = idx.indexOf(selected)
        if (sk >= 0 && selected < details.size) {
            val p = pts[sk]
            val label = details[selected]
            val tw = tipText.measureText(label) + 16f * d
            var left = p.x - tw / 2f
            left = max(4f * d, min(left, w - tw - 4f * d))
            val top = max(2f * d, p.y - 36f * d)
            val r = RectF(left, top, left + tw, top + 22f * d)
            canvas.drawRoundRect(r, 8f * d, 8f * d, tipBg)
            val fm = tipText.fontMetrics
            canvas.drawText(label, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, tipText)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) {
            parent?.requestDisallowInterceptTouchEvent(true)
            var best = -1
            var bestDist = Float.MAX_VALUE
            for (i in values.indices) {
                if (values[i] == null) continue
                val dist = abs(xAt(i) - e.x)
                if (dist < bestDist) { bestDist = dist; best = i }
            }
            if (best != selected) { selected = best; invalidate() }
            return true
        }
        return super.onTouchEvent(e)
    }
}

/** Animated rounded bar chart; values are 0..1. */
class BarChartView(context: Context) : View(context) {
    var values: List<Float> = emptyList()
    var labels: List<String> = emptyList()
    var threshold = 0.5f
    var progress = 1f
    private val d = context.resources.displayMetrics.density
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#8E8E93"); textSize = 10f * d; textAlign = Paint.Align.CENTER }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1C1C1E"); textSize = 10f * d; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#C7C7CC"); strokeWidth = d; style = Paint.Style.STROKE; pathEffect = DashPathEffect(floatArrayOf(8f * d, 6f * d), 0f) }

    fun animateIn(ms: Long = 500) {
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = ms
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { v ->
            progress = v.animatedValue as Float
            invalidate()
        }
        a.start()
    }

    override fun onDraw(canvas: Canvas) {
        val n = values.size
        if (n == 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        val padT = 18f * d
        val padB = 22f * d
        val plotH = h - padT - padB
        val slot = w / n
        val barW = min(slot * 0.58f, 30f * d)
        val ty = padT + plotH * (1f - threshold)
        val path = Path()
        path.moveTo(0f, ty)
        path.lineTo(w, ty)
        canvas.drawPath(path, dash)
        for (i in 0 until n) {
            val v = values[i].coerceIn(0f, 1f)
            val left = i * slot + (slot - barW) / 2f
            val bh = max(plotH * v * progress, 3f * d)
            val top = padT + plotH - bh
            val isLast = i == n - 1
            barPaint.color = if (v <= 0f) Color.parseColor("#ECECF1") else if (isLast) Color.parseColor("#2F6F4F") else tint(Color.parseColor("#2F6F4F"), 0.6f)
            canvas.drawRoundRect(RectF(left, top, left + barW, padT + plotH), barW / 2.5f, barW / 2.5f, barPaint)
            if (n <= 7 && v > 0f) canvas.drawText("${(v * 100).toInt()}", left + barW / 2f, top - 4f * d, valuePaint)
            val label = labels.getOrNull(i) ?: ""
            if (label.isNotEmpty()) canvas.drawText(label, left + barW / 2f, h - 6f * d, labelPaint)
        }
    }
}

/** GitHub-style activity grid. cells are oldest..newest; -1 means no data. offset = row (Mon=0) of the first cell. */
class HeatmapView(context: Context) : View(context) {
    private var cells: List<Float> = emptyList()
    private var offset = 0
    private val d = context.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gap get() = 3f * d

    fun setData(c: List<Float>, off: Int) {
        cells = c
        offset = off
        requestLayout()
        invalidate()
    }

    private fun cols(): Int = max(1, (offset + cells.size + 6) / 7)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val cell = (w - gap * (cols() - 1)) / cols()
        setMeasuredDimension(w, (cell * 7 + gap * 6).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val cell = (width - gap * (cols() - 1)) / cols()
        for (i in cells.indices) {
            val pos = offset + i
            val col = pos / 7
            val row = pos % 7
            val x = col * (cell + gap)
            val y = row * (cell + gap)
            val v = cells[i]
            paint.color = when {
                v < 0f -> Color.parseColor("#EFEFF4")
                v < 0.25f -> Color.parseColor("#D3E8DC")
                v < 0.5f -> Color.parseColor("#A3D0B8")
                v < 0.75f -> Color.parseColor("#62A885")
                else -> Color.parseColor("#2F6F4F")
            }
            canvas.drawRoundRect(RectF(x, y, x + cell, y + cell), cell * 0.28f, cell * 0.28f, paint)
        }
    }
}

/** Scrollable two-digit wheel for the timer: drag up/down to change the value. */
class WheelView(context: Context, private val maxValue: Int) : View(context) {
    var onChange: ((Int) -> Unit)? = null
    var mainColor = Color.parseColor("#2F6F4F")
    var value: Int = 0
        set(v) {
            val n = maxValue + 1
            field = ((v % n) + n) % n
            invalidate()
        }
    private val d = context.resources.displayMetrics.density
    private val step = 52f * d
    private var dragY = 0f
    private var lastY = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((96f * d).toInt(), (step * 3f).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val cy = height / 2f
        val base = 54f * d
        val n = maxValue + 1
        for (k in -2..2) {
            val v = (((value + k) % n) + n) % n
            val y = cy + k * step + dragY
            val dist = min(abs(y - cy) / step, 1.7f)
            paint.color = mainColor
            paint.alpha = (255 * (1f - dist / 1.9f)).toInt().coerceIn(0, 255)
            paint.textSize = base * (1f - 0.2f * min(dist, 1.5f))
            val fm = paint.fontMetrics
            canvas.drawText(String.format("%02d", v), width / 2f, y - (fm.ascent + fm.descent) / 2f, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                lastY = e.y
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                dragY += e.y - lastY
                lastY = e.y
                var changed = false
                while (dragY <= -step) { value = value + 1; dragY += step; changed = true }
                while (dragY >= step) { value = value - 1; dragY -= step; changed = true }
                if (changed) {
                    onChange?.invoke(value)
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val a = ValueAnimator.ofFloat(dragY, 0f)
                a.duration = 160
                a.addUpdateListener { v ->
                    dragY = v.animatedValue as Float
                    invalidate()
                }
                a.start()
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}
