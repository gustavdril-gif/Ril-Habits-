package com.airil.rillrebirth

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.Vibrator
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.*
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    // ---- palette ----
    internal val bg = Color.parseColor("#F2F2F7")
    internal val ink = Color.parseColor("#1C1C1E")
    internal val subtle = Color.parseColor("#8E8E93")
    internal val green = Color.parseColor("#2F6F4F")
    internal val greenSoft = Color.parseColor("#E3F1E9")
    internal val amber = Color.parseColor("#F2A93B")
    internal val amberDark = Color.parseColor("#B7791F")
    internal val amberSoft = Color.parseColor("#FDF1DC")
    internal val blue = Color.parseColor("#6C8EF5")
    internal val danger = Color.parseColor("#E5484D")
    internal val dangerSoft = Color.parseColor("#FDECEC")
    internal val line = Color.parseColor("#ECECF1")

    // ---- state ----
    internal var scrollView: ScrollView? = null
    internal var lastTab = ""
    internal var screen = "tab"
    internal lateinit var root: LinearLayout
    internal var navBar: LinearLayout? = null
    internal var navSide = -1
    private val navTabs = listOf(Triple("Home", "Beranda", R.drawable.ic_home), Triple("Checklist", "Checklist", R.drawable.ic_checklist), Triple("Workout", "Workout", R.drawable.ic_workout), Triple("Jadwal", "Jadwal", R.drawable.ic_calendar), Triple("Statistik", "Statistik", R.drawable.ic_stats))
    internal lateinit var content: LinearLayout
    internal var selectedTab = "Home"
    internal var tasks = mutableListOf<RillTask>()
    internal var done = mutableSetOf<Int>()
    internal var stats: List<DayStat> = emptyList()
    internal var animating = false
    internal var celebrateNext = false
    internal var showChecklistAnyway = false
    internal var statsPeriod = 0
    internal var moodPeriod = 0
    internal var draft: Draft? = null
    internal val handler = Handler(Looper.getMainLooper())

    // timer state: 0 = idle, 1 = running, 2 = paused
    internal var timerSet = 60L
    internal var timerRemaining = 60L
    internal var timerState = 0
    internal var timerEndAt = 0L
    internal var flowWorkoutId = -1L
    internal var onTimerScreen = false
    internal var timerBox: LinearLayout? = null
    internal var timerRing: RingView? = null

    internal val timerTick = object : Runnable {
        override fun run() {
            if (timerState != 1) return
            timerRemaining = ((timerEndAt - SystemClock.elapsedRealtime() + 999) / 1000).coerceAtLeast(0)
            val ring = timerRing
            if (ring != null && onTimerScreen) {
                ring.centerText = formatTime(timerRemaining)
                ring.segs = listOf(RingView.Seg(amber, timerSet.toInt(), (timerSet - timerRemaining).toInt()))
                ring.invalidate()
            }
            if (timerRemaining <= 0) finishTimer() else handler.postDelayed(this, 200)
        }
    }

    private val refreshRunnable = Runnable { if (screen == "tab") render(false) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedTab = savedInstanceState?.getString("tab") ?: "Home"
        timerSet = prefs().getLong("rest_seconds", 60L).coerceIn(1L, 5999L)
        timerRemaining = timerSet
        createNotificationChannel()
        render(true)
        ReminderScheduler.scheduleAll(this)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tab", selectedTab)
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized && screen == "tab") render(false)
    }

    @Deprecated("Back handling for sub-screens")
    override fun onBackPressed() {
        if (screen != "tab") { draft = null; render(true) } else super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacks(timerTick)
        super.onDestroy()
    }

    // ---- basic helpers ----
    internal fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    internal fun prefs(): SharedPreferences = getSharedPreferences("rill_data", Context.MODE_PRIVATE)
    internal fun shape(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }
    internal fun drawable(id: Int): Drawable = resources.getDrawable(id, theme)
    internal fun formatTime(seconds: Long): String = String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    internal fun dayShort(d: Int): String = Smart.weekdayLabel(d)
    internal val weekOrder = listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)

    internal fun text(value: String, size: Float, bold: Boolean = false, color: Int = ink): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(2), dp(3), dp(2), dp(3))
    }

    internal fun hint(value: String): TextView = text(value, 12f, false, subtle).apply { setPadding(dp(4), dp(6), dp(4), dp(6)) }

    internal fun button(label: String, primary: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f; setTypeface(typeface, Typeface.BOLD)
        stateListAnimator = null; elevation = 0f; minHeight = 0; minimumHeight = 0
        setTextColor(if (primary) Color.WHITE else green)
        background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#22000000")), shape(if (primary) green else greenSoft, 14), shape(Color.BLACK, 14))
        val lp = LinearLayout.LayoutParams(-1, dp(48)); lp.setMargins(0, dp(6), 0, dp(6)); layoutParams = lp
        setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(80).start()
            else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            false
        }
        setOnClickListener { action() }
    }

    internal fun card(vPad: Int = 14): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(vPad), dp(16), dp(vPad)); background = shape(Color.WHITE, 20)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(6), 0, dp(6)); layoutParams = lp
    }

    internal fun listCard(): LinearLayout = card(8).apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }

    internal fun hbar(percent: Int, color: Int, heightDp: Int = 8): LinearLayout {
        val p = percent.coerceIn(0, 100)
        val track = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; background = shape(Color.parseColor("#E5E5EA"), 6)
            layoutParams = LinearLayout.LayoutParams(-1, dp(heightDp)).apply { setMargins(0, dp(6), 0, dp(6)) }
        }
        val fill = View(this).apply { background = shape(color, 6) }
        val rest = View(this)
        track.addView(fill, LinearLayout.LayoutParams(0, -1, if (animating) 0f else p.toFloat()))
        track.addView(rest, LinearLayout.LayoutParams(0, -1, if (animating) 100f else (100 - p).toFloat()))
        if (animating && p > 0) {
            val a = ValueAnimator.ofFloat(0f, p.toFloat())
            a.duration = 500
            a.interpolator = DecelerateInterpolator()
            a.addUpdateListener { v ->
                val w = v.animatedValue as Float
                (fill.layoutParams as LinearLayout.LayoutParams).weight = w
                (rest.layoutParams as LinearLayout.LayoutParams).weight = 100f - w
                track.requestLayout()
            }
            a.start()
        }
        return track
    }

    internal fun section(title: String) { content.addView(text(title, 18f, true).apply { setPadding(dp(4), dp(14), dp(4), dp(4)) }) }
    internal fun chevron(): ImageView = ImageView(this).apply { setImageResource(R.drawable.ic_chevron); setColorFilter(subtle) }
    internal fun backLink(label: String, action: () -> Unit): TextView = text(label, 15f, true, green).apply { setPadding(dp(4), dp(4), dp(12), dp(10)); setOnClickListener { action() } }

    internal fun pair(a: Button, b: Button): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(0, dp(6), dp(4), dp(6)) })
        addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(4), dp(6), 0, dp(6)) })
    }

    internal fun segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; background = shape(Color.parseColor("#EBEBF0"), 12); setPadding(dp(3), dp(3), dp(3), dp(3))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, dp(8)) }
        }
        options.forEachIndexed { i, label ->
            val t = TextView(this).apply {
                text = label; gravity = Gravity.CENTER; textSize = 13f; setPadding(0, dp(7), 0, dp(7))
                setTextColor(if (i == selected) ink else subtle)
                if (i == selected) { background = shape(Color.WHITE, 10); setTypeface(typeface, Typeface.BOLD) }
                setOnClickListener { onSelect(i) }
            }
            box.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        return box
    }

    internal fun chip(label: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER
        setTextColor(if (selected) Color.WHITE else ink)
        background = shape(if (selected) green else Color.parseColor("#EFEFF4"), 18)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onClick() }
    }

    internal fun statTile(emoji: String, value: String, label: String, sub: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = shape(Color.WHITE, 20); setPadding(dp(14), dp(12), dp(14), dp(12))
        addView(text(emoji, 20f))
        addView(text(value, 26f, true))
        addView(text(label, 12f, true, ink))
        addView(text(sub, 10f, false, subtle))
    }

    internal fun tileRow(vararg tiles: View): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) } }
        tiles.forEachIndexed { i, t ->
            row.addView(t, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(if (i == 0) 0 else dp(4), 0, if (i == tiles.size - 1) 0 else dp(4), 0) })
        }
        return row
    }

    // ---- animation helpers ----
    internal fun pop(v: View) {
        v.animate().scaleX(1.03f).scaleY(1.03f).setDuration(110).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(140).start() }.start()
    }

    internal fun tintRow(row: View, from: Int, to: Int, radius: Int) {
        val a = ValueAnimator.ofObject(ArgbEvaluator(), from, to)
        a.duration = 250
        a.addUpdateListener { v -> row.background = shape(v.animatedValue as Int, radius) }
        a.start()
    }

    private fun animateChildren() {
        for (i in 0 until content.childCount) {
            val v = content.getChildAt(i)
            v.alpha = 0f
            v.translationY = dp(18).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(minOf(i, 8) * 45L).setDuration(450).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    internal fun scheduleRefresh() {
        handler.removeCallbacks(refreshRunnable)
        handler.postDelayed(refreshRunnable, 320)
    }

    // ---- shared logic ----
    internal fun refreshData() {
        tasks = TaskStore.load(this)
        done = TaskStore.doneToday(this)
        stats = Smart.dayStats(this, tasks, 365)
    }

    internal fun todaySessions(): List<WorkoutSession> = WorkoutStore.sessionsForDate(this)

    /** A prayer task that is still unchecked 2 hours after its time has lapsed ("gugur") and no longer counts today. */
    internal fun isLapsed(t: RillTask): Boolean = !done.contains(t.id) && Smart.isPrayer(t) && nowMinutes() > taskMinutes(t) + Smart.PRAYER_GRACE_MIN

    internal fun allDoneToday(): Boolean {
        val s = todaySessions()
        val live = tasks.filter { !isLapsed(it) }
        return (live.isNotEmpty() || s.isNotEmpty()) && live.all { done.contains(it.id) } && s.all { WorkoutStore.isDone(this, it.id) }
    }

    internal fun nowMinutes(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    internal fun taskMinutes(t: RillTask): Int {
        val p = t.time.split(":")
        return (p.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (p.getOrNull(1)?.toIntOrNull() ?: 0)
    }

    internal fun openWorkout(id: Long) {
        selectedTab = "Workout"
        render(false)
        showWorkoutDetail(id)
    }

    private fun checkLevelUp() {
        val total = TaskStore.totalXp(this) + WorkoutStore.totalWorkoutXp(this)
        val level = total / 100 + 1
        val stored = prefs().getInt("max_level", -1)
        if (stored < 0) { prefs().edit().putInt("max_level", level).apply(); return }
        if (level > stored) {
            prefs().edit().putInt("max_level", level).apply()
            AlertDialog.Builder(this, R.style.RillDialog).setTitle("Level naik! 🎉").setMessage("Kamu sekarang Level $level · ${Smart.levelTitle(level)}. Konsistensimu terbayar.").setPositiveButton("Mantap", null).show()
        }
    }

    // ---- row builders ----
    internal fun habitRow(task: RillTask, isDone: Boolean, overdue: Boolean, lapsed: Boolean = false, onToggle: (Boolean) -> Unit): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
            background = shape(if (isDone) greenSoft else if (lapsed) Color.parseColor("#F7F7FA") else Color.WHITE, 14)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(2)) }
        }
        val title = text(task.name, 15f, false, if (isDone || lapsed) subtle else ink)
        if (isDone) title.paintFlags = title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        val subText = if (lapsed) "${task.time} · ${task.category} · Gugur (lewat ${Smart.PRAYER_GRACE_MIN / 60} jam)" else "${task.time} · ${task.category} · ${task.xp} EXP" + if (overdue && !isDone) " · Terlewat" else ""
        val sub = text(subText, 12f, false, if (overdue && !isDone && !lapsed) danger else subtle)
        val cb = CheckBox(this).apply { setButtonDrawable(R.drawable.cb_selector); setPadding(0, 0, 0, 0); minWidth = 0; minHeight = 0; isChecked = isDone; if (lapsed) { isEnabled = false; alpha = 0.35f } }
        cb.setOnCheckedChangeListener { _, v ->
            tintRow(r, if (v) Color.WHITE else greenSoft, if (v) greenSoft else Color.WHITE, 14)
            if (v) title.paintFlags = title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG else title.paintFlags = title.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            title.setTextColor(if (v) subtle else ink)
            pop(r)
            if (v) cb.animate().scaleX(1.25f).scaleY(1.25f).setDuration(110).withEndAction { cb.animate().scaleX(1f).scaleY(1f).setDuration(140).start() }.start()
            onToggle(v)
        }
        r.addView(cb, LinearLayout.LayoutParams(dp(26), dp(26)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(4), 0) }
        col.addView(title); col.addView(sub)
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (lapsed) r.setOnClickListener { showLapsedDialog(task, onToggle) } else r.setOnClickListener { cb.toggle() }
        return r
    }

    private fun showLapsedDialog(task: RillTask, onToggle: (Boolean) -> Unit) {
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("${task.name} sudah gugur")
            .setMessage("Waktunya sudah lewat lebih dari ${Smart.PRAYER_GRACE_MIN / 60} jam, jadi tidak dihitung di progres hari ini. Kalau kamu tetap menunaikannya, kamu bisa mencatatnya.")
            .setPositiveButton("Tetap catat selesai") { _, _ -> onToggle(true) }
            .setNegativeButton("Tutup", null).show()
    }

    /** Workout-style row: round amber check on the right side. */
    internal fun woRow(title: String, sub: String, checked: Boolean, next: Boolean, tapToggles: Boolean, onChange: (Boolean) -> Unit, onTap: (() -> Unit)? = null, onInfo: (() -> Unit)? = null): LinearLayout {
        val base = if (next) Color.parseColor("#FFF8EA") else Color.WHITE
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(10), dp(12))
            background = shape(if (checked) amberSoft else base, 14)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(2)) }
        }
        val t = text(title, 15f, true, if (checked) subtle else ink)
        if (checked) t.paintFlags = t.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        val s = text(if (next && !checked) "▶ Berikutnya · $sub" else sub, 12f, next && !checked, if (next && !checked) amberDark else subtle)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(t); col.addView(s)
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (onInfo != null) {
            val info = TextView(this).apply {
                text = "i"; gravity = Gravity.CENTER; textSize = 13f; setTextColor(subtle); setTypeface(typeface, Typeface.BOLD_ITALIC)
                background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(Color.parseColor("#F2F2F7")) }
                setOnClickListener { onInfo() }
            }
            r.addView(info, LinearLayout.LayoutParams(dp(28), dp(28)).apply { setMargins(dp(6), 0, dp(12), 0) })
        }
        val cb = CheckBox(this).apply { setButtonDrawable(R.drawable.cb_wo_selector); setPadding(0, 0, 0, 0); minWidth = 0; minHeight = 0; isChecked = checked }
        cb.setOnCheckedChangeListener { _, v ->
            tintRow(r, if (v) base else amberSoft, if (v) amberSoft else base, 14)
            pop(r)
            if (v) cb.animate().scaleX(1.3f).scaleY(1.3f).setDuration(110).withEndAction { cb.animate().scaleX(1f).scaleY(1f).setDuration(140).start() }.start()
            onChange(v)
        }
        r.addView(cb, LinearLayout.LayoutParams(dp(28), dp(28)))
        if (tapToggles) r.setOnClickListener { cb.toggle() } else if (onTap != null) r.setOnClickListener { onTap() }
        return r
    }

    internal fun listItem(title: String, sub: String, onClick: () -> Unit): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(title, 15f, false, ink)); if (sub.isNotBlank()) col.addView(text(sub, 12f, false, subtle))
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(chevron(), LinearLayout.LayoutParams(dp(18), dp(18)))
        r.setOnClickListener { onClick() }
        return r
    }

    // ---- toggles ----
    internal fun onTaskToggled(task: RillTask, checked: Boolean) {
        val before = allDoneToday()
        if (checked) done.add(task.id) else done.remove(task.id)
        TaskStore.saveDone(this, done)
        if (!before && allDoneToday()) celebrateNext = true
        scheduleRefresh()
    }

    internal fun onSessionToggled(id: Long, checked: Boolean) {
        val before = allDoneToday()
        WorkoutStore.setDone(this, id, checked)
        if (!before && allDoneToday()) celebrateNext = true
        scheduleRefresh()
    }

    // ---- frame ----
    private fun headerFor(tab: String): Pair<String, String> {
        if (tab != "Home") return Pair(mapOf("Checklist" to "Checklist", "Workout" to "Workout", "Jadwal" to "Jadwal", "Statistik" to "Statistik")[tab] ?: tab, "RilHabit · Pelan-pelan, konsisten.")
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greet = when {
            h < 4 -> "Selamat malam 🌙"
            h < 11 -> "Selamat pagi 🌅"
            h < 15 -> "Selamat siang ☀️"
            h < 18 -> "Selamat sore 🌇"
            else -> "Selamat malam 🌙"
        }
        return Pair(greet, homeHeadline())
    }

    private fun homeHeadline(): String {
        val sessions = todaySessions()
        val total = tasks.count { !isLapsed(it) } + sessions.size
        val completed = tasks.count { done.contains(it.id) } + sessions.count { WorkoutStore.isDone(this, it.id) }
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val now = nowMinutes()
        val pending = tasks.filter { !done.contains(it.id) && !isLapsed(it) }.sortedBy { taskMinutes(it) }
        val overdue = pending.count { taskMinutes(it) < now }
        val next = pending.firstOrNull { taskMinutes(it) >= now }
        return when {
            total == 0 -> "Mulai dengan menambah kegiatan di menu Jadwal."
            allDoneToday() -> "Semua selesai hari ini. Kamu luar biasa! 🎉"
            completed == 0 && h < 11 -> "Hari baru, mulai dari satu langkah kecil."
            overdue > 0 -> "$overdue kegiatan terlewat — kejar satu per satu."
            next != null -> "Selanjutnya: ${next.name} (${next.time})"
            else -> "Tinggal sedikit lagi. Selesaikan dengan tenang."
        }
    }

    internal fun render(animate: Boolean = false) {
        screen = "tab"; onTimerScreen = false; timerRing = null; timerBox = null
        animating = animate
        refreshData()
        val keepY = if (!animate && lastTab == selectedTab) (scrollView?.scrollY ?: 0) else 0
        lastTab = selectedTab
        val sw = resources.displayMetrics.widthPixels
        val side = if (sw > dp(592)) (sw - dp(560)) / 2 else dp(16)
        if (navBar == null || navSide != side) {
            root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
            navBar = buildNav(side); navSide = side
            root.addView(navBar)
            setContentView(root)
        } else {
            for (i in root.childCount - 1 downTo 0) { if (root.getChildAt(i) !== navBar) root.removeViewAt(i) }
        }
        val (title, sub) = headerFor(selectedTab)
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(side + dp(4), dp(18), side + dp(4), dp(6)) }
        header.addView(text(title, 30f, true, ink)); header.addView(text(sub, 13f, false, subtle)); root.addView(header, 0)
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        scrollView = scroll
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(side, dp(6), side, dp(16)) }
        scroll.addView(content)
        root.addView(scroll, 1, LinearLayout.LayoutParams(-1, 0, 1f))
        when (selectedTab) {
            "Home" -> showHome()
            "Checklist" -> showChecklist()
            "Workout" -> showWorkout()
            "Jadwal" -> showSchedule()
            "Statistik" -> showStats()
        }
        applyNavSelection()
        if (animate) animateChildren()
        if (keepY > 0) scroll.post { scroll.scrollTo(0, keepY) }
        if (selectedTab == "Home") checkLevelUp()
    }

    private fun buildNav(side: Int): LinearLayout {
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(6), dp(6), dp(6)); background = shape(Color.WHITE, 30); elevation = dp(3).toFloat() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(side - dp(2), dp(4), side - dp(2), dp(12)); nav.layoutParams = lp
        navTabs.forEach { (key, label, icon) ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)); tag = key }
            item.addView(ImageView(this).apply { setImageResource(icon) }, LinearLayout.LayoutParams(dp(22), dp(22)))
            item.addView(TextView(this).apply { text = label; textSize = 10f; gravity = Gravity.CENTER; maxLines = 1; setPadding(0, dp(2), 0, 0) })
            nav.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        nav.setOnTouchListener { _, e -> handleNavTouch(nav, e) }
        return nav
    }

    /** Tap a tab, or press and slide sideways across the bar to flick through the menus quickly. */
    private fun handleNavTouch(nav: LinearLayout, e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            nav.parent?.requestDisallowInterceptTouchEvent(true)
            val count = nav.childCount
            if (count == 0) return true
            var key: String? = null
            for (i in 0 until count) {
                val c = nav.getChildAt(i)
                if (e.x >= c.left && e.x < c.right) { key = c.tag as? String; break }
            }
            if (key == null) key = nav.getChildAt(if (e.x < nav.width / 2f) 0 else count - 1).tag as? String
            if (key != null && (key != selectedTab || screen != "tab")) {
                selectedTab = key; showChecklistAnyway = false
                nav.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                render(true)
            }
        }
        return true
    }

    private fun applyNavSelection() {
        val nav = navBar ?: return
        for (i in 0 until nav.childCount) {
            val item = nav.getChildAt(i) as LinearLayout
            val sel = item.tag == selectedTab
            item.background = if (sel) shape(greenSoft, 22) else null
            (item.getChildAt(0) as ImageView).setColorFilter(if (sel) green else subtle)
            val label = item.getChildAt(1) as TextView
            label.setTextColor(if (sel) green else subtle)
            label.paint.isFakeBoldText = sel
            label.invalidate()
        }
    }

    // ---- completion card (mood + evaluation), only when everything is done ----
    internal fun completionCard(): LinearLayout {
        val c = card(18)
        c.background = shape(greenSoft, 20)
        c.addView(text("🎉 Semua selesai!", 20f, true, green))
        c.addView(text("Kerja bagus hari ini. Catat perasaanmu dan tutup hari dengan evaluasi singkat.", 13f, false, ink))
        val today = TaskStore.today()
        val mood = WorkoutStore.mood(this, today)
        val mv = mood?.optInt("value", 0) ?: 0
        if (mv in 1..5) {
            c.addView(text("Mood hari ini: ${Smart.moodEmojis[mv - 1]} ${Smart.moodLabels[mv - 1]}", 15f, true).apply { setPadding(dp(2), dp(12), dp(2), dp(4)) })
            c.addView(button("Ubah mood / tambah catatan") { showMoodSheet(-1) })
        } else {
            c.addView(text("Bagaimana perasaanmu?", 14f, true).apply { setPadding(dp(2), dp(12), dp(2), dp(6)) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0..4) {
                val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = shape(Color.WHITE, 16); setPadding(0, dp(10), 0, dp(8)) }
                tile.addView(text(Smart.moodEmojis[i], 28f).apply { gravity = Gravity.CENTER })
                tile.addView(text(Smart.moodLabels[i], 9f, false, subtle).apply { gravity = Gravity.CENTER })
                tile.setOnClickListener {
                    pop(tile)
                    WorkoutStore.saveMood(this, today, i + 1, "")
                    Toast.makeText(this, "Mood tersimpan ${Smart.moodEmojis[i]}", Toast.LENGTH_SHORT).show()
                    handler.postDelayed({ if (screen == "tab") render(false) }, 250)
                }
                row.addView(tile, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
            }
            c.addView(row)
        }
        val hasReview = prefs().getString("review2_$today", null) != null
        c.addView(button(if (hasReview) "Evaluasi malam ✓ (ubah)" else "Evaluasi malam", !hasReview) { showReviewDialog() })
        if (celebrateNext) {
            celebrateNext = false
            c.scaleX = 0.9f; c.scaleY = 0.9f; c.alpha = 0f
            c.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(500).setInterpolator(DecelerateInterpolator()).start()
        }
        return c
    }

    // ---- HOME ----
    private fun legendRow(label: String, d: Int, t: Int, color: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(3), 0, dp(3))
        val dot = View(context)
        dot.background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(color) }
        addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)))
        addView(text("$label  $d/$t", 13f, false, ink).apply { setPadding(dp(8), 0, 0, 0) })
    }

    private fun showHome() {
        val sessions = todaySessions()
        val prayer = tasks.filter { Smart.isPrayer(it) && !isLapsed(it) }
        val lapsedList = tasks.filter { isLapsed(it) }
        val other = tasks.filter { !Smart.isPrayer(it) }
        val pT = prayer.size; val pD = prayer.count { done.contains(it.id) }
        val oT = other.size; val oD = other.count { done.contains(it.id) }
        val wT = sessions.size; val wD = sessions.count { WorkoutStore.isDone(this, it.id) }
        val total = pT + oT + wT; val completed = pD + oD + wD
        val percent = if (total == 0) 0 else completed * 100 / total
        val allDone = allDoneToday()

        // hero: 3-colour ring
        val hero = card(16)
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val ring = RingView(this).apply {
            segs = listOf(RingView.Seg(green, pT, pD), RingView.Seg(amber, wT, wD), RingView.Seg(blue, oT, oD))
            centerText = "$percent%"; centerSub = "selesai"
        }
        top.addView(ring, LinearLayout.LayoutParams(dp(136), dp(136)))
        val legend = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, 0, 0) }
        legend.addView(text("Progres hari ini", 12f, false, subtle))
        legend.addView(text("$completed dari $total", 24f, true))
        if (pT > 0) legend.addView(legendRow("Ibadah", pD, pT, green))
        if (wT > 0) legend.addView(legendRow("Workout", wD, wT, amber))
        if (oT > 0) legend.addView(legendRow("Lainnya", oD, oT, blue))
        if (lapsedList.isNotEmpty()) legend.addView(text("${lapsedList.size} ibadah gugur", 11f, false, subtle).apply { setPadding(dp(2), dp(4), dp(2), dp(0)) })
        top.addView(legend, LinearLayout.LayoutParams(0, -2, 1f))
        hero.addView(top)
        val totalXp = TaskStore.totalXp(this) + WorkoutStore.totalWorkoutXp(this)
        val level = totalXp / 100 + 1; val inLevel = totalXp % 100
        val todayXp = TaskStore.xpFor(this, done) + WorkoutStore.workoutXpToday(this)
        val meta = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        meta.addView(text("Level $level · ${Smart.levelTitle(level)}", 12f, true), LinearLayout.LayoutParams(0, -2, 1f))
        meta.addView(text("+$todayXp EXP hari ini", 12f, true, green))
        hero.addView(meta)
        hero.addView(hbar(inLevel, green))
        hero.addView(text("$inLevel/100 EXP · ${100 - inLevel} lagi ke Level ${level + 1}", 11f, false, subtle))
        content.addView(hero)
        if (animating) ring.animateIn()

        // workout in progress
        val inProg = WorkoutStore.inProgress(this)
        if (inProg != null) {
            val cks = WorkoutStore.exerciseChecks(this, inProg.id).size
            val c = card(); c.background = shape(amberSoft, 20)
            c.addView(text("🏋️ Sesi sedang berlangsung", 12f, true, amberDark))
            c.addView(text(inProg.name, 18f, true))
            c.addView(text("$cks dari ${inProg.exercises.size} gerakan selesai", 13f, false, subtle))
            c.addView(hbar(if (inProg.exercises.isEmpty()) 0 else cks * 100 / inProg.exercises.size, amber))
            c.addView(button("Lanjutkan sesi", true) { openWorkout(inProg.id) })
            content.addView(c)
        }

        // streak risk (evening)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val wStreak = Smart.workoutStreak(stats)
        val pendingSession = sessions.firstOrNull { !WorkoutStore.isDone(this, it.id) }
        if (inProg == null && hour >= 17 && wStreak > 0 && pendingSession != null) {
            val c = card(); c.background = shape(dangerSoft, 20)
            c.addView(text("🔥 Streak $wStreak hari menunggumu", 16f, true, danger))
            c.addView(text("Selesaikan ${pendingSession.name} hari ini agar streak-mu tidak putus.", 13f, false, ink))
            c.addView(button("Mulai sekarang", true) { openWorkout(pendingSession.id) })
            content.addView(c)
        }

        // gentle suggestion after a low-mood day
        val yMood = WorkoutStore.mood(this, WorkoutStore.date(-1))?.optInt("value", 0) ?: 0
        if (yMood in 1..2 && WorkoutStore.mood(this, TaskStore.today()) == null && !allDone) {
            val c = card(); c.background = shape(greenSoft, 20)
            c.addView(text("🌿 Pelan-pelan hari ini", 16f, true, green))
            c.addView(text("Kemarin moodmu kurang baik. Tidak apa-apa — coba mulai dengan peregangan ringan.", 13f, false, ink))
            c.addView(button("Lihat program ringan") { selectedTab = "Workout"; render(false); showPrograms() })
            content.addView(c)
        }

        if (allDone) {
            content.addView(completionCard())
        } else {
            val now = nowMinutes()
            val pending = tasks.filter { !done.contains(it.id) && !isLapsed(it) }.sortedBy { taskMinutes(it) }
            val ordered = pending.filter { taskMinutes(it) < now } + pending.filter { taskMinutes(it) >= now }
            if (ordered.isNotEmpty()) {
                section("Selanjutnya")
                val list = listCard()
                ordered.take(4).forEach { t -> list.addView(habitRow(t, false, taskMinutes(t) < now) { v -> onTaskToggled(t, v) }) }
                content.addView(list)
                if (ordered.size > 4) content.addView(button("Lihat semua (${ordered.size})") { selectedTab = "Checklist"; render(true) })
            }
        }

        // streak tiles
        content.addView(tileRow(
            statTile("🔥", "${Smart.habitStreak(stats)}", "Streak kebiasaan", "min. 50% tugas per hari"),
            statTile("💪", "$wStreak", "Streak workout", "hari istirahat tidak memutus")
        ))

        if (sessions.isNotEmpty() && inProg == null) {
            val w = card(); w.addView(text("Workout hari ini", 16f, true))
            w.addView(text("$wD dari ${sessions.size} sesi selesai", 14f, false, subtle))
            w.addView(button("Buka Workout") { selectedTab = "Workout"; render(true) })
            content.addView(w)
        }

        val note = card(); note.addView(text("Daily Note", 16f, true))
        val edit = EditText(this).apply { hint = "Tulis catatan singkat untuk hari ini…"; minLines = 2; textSize = 14f; gravity = Gravity.TOP; background = shape(bg, 12); setPadding(dp(12), dp(10), dp(12), dp(10)); setText(prefs().getString("daily_note_${TaskStore.today()}", "") ?: "") }
        note.addView(edit, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, dp(4)) })
        note.addView(button("Simpan catatan") { prefs().edit().putString("daily_note_${TaskStore.today()}", edit.text.toString()).apply(); Toast.makeText(this, "Daily Note tersimpan.", Toast.LENGTH_SHORT).show() })
        content.addView(note)
    }

    // ---- CHECKLIST ----
    private fun showChecklist() {
        val sessions = todaySessions()
        val total = tasks.count { !isLapsed(it) } + sessions.size
        val completed = tasks.count { done.contains(it.id) } + sessions.count { WorkoutStore.isDone(this, it.id) }
        val summary = card()
        summary.addView(text("$completed dari $total item selesai", 14f, false, subtle))
        summary.addView(hbar(if (total == 0) 0 else completed * 100 / total, green))
        content.addView(summary)

        if (allDoneToday()) {
            content.addView(completionCard())
            content.addView(button(if (showChecklistAnyway) "Sembunyikan daftar" else "Lihat daftar checklist") { showChecklistAnyway = !showChecklistAnyway; render(false) })
            if (!showChecklistAnyway) return
        }

        section("Tugas harian")
        val now = nowMinutes()
        val sorted = tasks.sortedBy { it.time }
        if (sorted.isNotEmpty()) {
            val list = listCard()
            sorted.forEach { t -> list.addView(habitRow(t, done.contains(t.id), taskMinutes(t) < now, isLapsed(t)) { v -> onTaskToggled(t, v) }) }
            content.addView(list)
            if (sorted.any { isLapsed(it) }) content.addView(hint("Ibadah yang lewat lebih dari ${Smart.PRAYER_GRACE_MIN / 60} jam otomatis gugur dan tidak dihitung hari ini. Ketuk barisnya kalau kamu tetap ingin mencatatnya."))
        } else content.addView(hint("Belum ada kegiatan. Tambahkan lewat menu Jadwal."))

        section("Workout hari ini")
        if (sessions.isEmpty()) content.addView(hint("Tidak ada workout terjadwal hari ini. Hari istirahat 😌"))
        else {
            val list = listCard()
            sessions.forEach { s ->
                val cks = WorkoutStore.exerciseChecks(this, s.id).size
                val progress = if (cks > 0) " · $cks/${s.exercises.size} gerakan" else ""
                list.addView(woRow(s.name, "${s.time} · ${s.durationMinutes} menit$progress", WorkoutStore.isDone(this, s.id), false, false, { v -> onSessionToggled(s.id, v) }, { openWorkout(s.id) }))
            }
            content.addView(list)
            content.addView(hint("Ketuk sesi untuk membuka gerakan. Lingkaran di kanan menandai sesi selesai."))
        }
    }

    // ---- JADWAL ----
    private fun showSchedule() {
        content.addView(hint("Tugas dan workout disimpan di perangkat. Pengingat bergantung pada izin Android/MIUI."))
        content.addView(button("Tambah kegiatan checklist", true) { editTask(null) })
        content.addView(button("Pengingat tugas: ${if (prefs().getBoolean("reminders_enabled", true)) "Aktif" else "Nonaktif"}") { val on = !prefs().getBoolean("reminders_enabled", true); prefs().edit().putBoolean("reminders_enabled", on).apply(); ReminderScheduler.scheduleAll(this); render(false) })
        section("Kegiatan")
        if (tasks.isNotEmpty()) {
            val list = listCard(); val sorted = tasks.sortedBy { it.time }
            sorted.forEachIndexed { i, t -> list.addView(listItem(t.name, "${t.time} · ${t.category}") { editTask(t) }); if (i < sorted.size - 1) list.addView(View(this).apply { setBackgroundColor(line); layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { setMargins(dp(12), 0, dp(12), 0) } }) }
            content.addView(list)
        }
        section("Jadwal workout")
        val sessions = WorkoutStore.load(this)
        if (sessions.isEmpty()) content.addView(hint("Belum ada jadwal workout."))
        else {
            val list = listCard()
            sessions.forEach { s -> list.addView(listItem(s.name, "${if (s.oneOffDate.isNotBlank()) s.oneOffDate else s.days.sortedBy { weekOrder.indexOf(it) }.joinToString(" · ") { dayShort(it) }} · ${s.time}${if (s.active) "" else " · Dijeda"}") { showBuilder(s) }) }
            content.addView(list)
        }
        content.addView(button("Bikin Jadwal workout") { showBuilder(null) })
    }

    private fun editTask(existing: RillTask?) {
        val task = existing ?: RillTask((tasks.maxOfOrNull { it.id } ?: 0) + 1, "", "18:00", "Umum", 10, false)
        val act = this
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
        val name = EditText(this).apply { hint = "Nama kegiatan"; setText(task.name) }
        val time = EditText(this).apply {
            hint = "Jam"; setText(task.time); isFocusable = false
            setOnClickListener {
                val p = text.toString().split(":")
                TimePickerDialog(act, { _, h, m -> setText(String.format(Locale.US, "%02d:%02d", h, m)) }, p.getOrNull(0)?.toIntOrNull() ?: 18, p.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
            }
        }
        val category = EditText(this).apply { hint = "Kategori"; setText(task.category) }
        val xp = EditText(this).apply { hint = "EXP (angka)"; setText(task.xp.toString()); inputType = 2 }
        val reminder = CheckBox(this).apply { text = "Aktifkan pengingat harian"; isChecked = task.reminderEnabled }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
        listOf("Ibadah", "Belajar", "Olahraga", "Rutinitas", "Pengembangan diri", "Refleksi").forEach { c ->
            chips.addView(chip(c, false) { category.setText(c) }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(6), 0) })
        }
        box.addView(name); box.addView(time); box.addView(category)
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })
        box.addView(xp); box.addView(reminder)
        AlertDialog.Builder(this, R.style.RillDialog).setTitle(if (existing == null) "Tambah kegiatan" else "Edit kegiatan").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Simpan") { _, _ ->
            val tv = time.text.toString().trim()
            if (name.text.isNullOrBlank() || !Regex("^([01]?[0-9]|2[0-3]):[0-5][0-9]$").matches(tv)) { Toast.makeText(this, "Isi nama dan jam yang valid.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
            task.name = name.text.toString().trim(); task.time = String.format(Locale.US, "%02d:%02d", tv.substringBefore(":").toInt(), tv.substringAfter(":").toInt()); task.category = category.text.toString().ifBlank { "Umum" }; task.xp = (xp.text.toString().toIntOrNull() ?: 10).coerceIn(0, 500); task.reminderEnabled = reminder.isChecked
            if (existing == null) tasks.add(task); TaskStore.save(this, tasks); ReminderScheduler.scheduleAll(this); render(false)
        }.setNeutralButton(if (existing != null) "Hapus" else "Batal") { _, _ -> if (existing != null) { tasks.removeAll { it.id == task.id }; done.remove(task.id); TaskStore.save(this, tasks); TaskStore.saveDone(this, done); ReminderScheduler.scheduleAll(this); render(false) } }.setNegativeButton("Tutup", null).show()
    }

    // ---- sound / vibration ----
    internal fun playTet() {
        Thread {
            try {
                val sr = 22050
                val toneSamples = (sr * 0.16).toInt()
                val silence = (sr * 0.09).toInt()
                val bursts = 3
                val data = ShortArray((toneSamples + silence) * bursts)
                var idx = 0
                for (b in 0 until bursts) {
                    for (i in 0 until toneSamples) {
                        val t = i.toDouble() / sr
                        val env = if (i < 200) i / 200.0 else if (i > toneSamples - 300) (toneSamples - i) / 300.0 else 1.0
                        val s = Math.sin(2 * Math.PI * 1900 * t) + 0.5 * Math.sin(2 * Math.PI * 3800 * t)
                        data[idx++] = (Math.max(-1.0, Math.min(1.0, s * 0.95)) * env * 32000).toInt().toShort()
                    }
                    for (i in 0 until silence) data[idx++] = 0
                }
                val track = AudioTrack(AudioManager.STREAM_ALARM, sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, data.size * 2, AudioTrack.MODE_STATIC)
                track.write(data, 0, data.size)
                track.setVolume(1.0f)
                track.play()
                Thread.sleep((data.size * 1000L) / sr + 250)
                track.release()
            } catch (_: Exception) {}
        }.start()
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(longArrayOf(0, 220, 120, 220, 120, 220), -1)
        } catch (_: Exception) {}
    }

    internal fun finishTimer() {
        timerState = 0
        timerRemaining = timerSet
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        playTet()
        if (onTimerScreen) {
            val id = flowWorkoutId
            if (id >= 0) { flowWorkoutId = -1L; showWorkoutDetail(id) } else buildTimerBody()
        } else Toast.makeText(this, "⏰ Waktu timer selesai!", Toast.LENGTH_LONG).show()
    }

    private fun createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= 26) { val channel = android.app.NotificationChannel("rill_reminders", "Pengingat RilHabit", android.app.NotificationManager.IMPORTANCE_DEFAULT); getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel) }
    }
}
