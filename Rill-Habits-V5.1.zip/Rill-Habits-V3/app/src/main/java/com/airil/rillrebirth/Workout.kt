package com.airil.rillrebirth

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import java.util.Calendar
import java.util.Locale

class Draft(
    var id: Long,
    var name: String,
    var time: String,
    var duration: Int,
    var days: MutableSet<Int>,
    var oneOffDate: String,
    var notes: String,
    var reminder: Boolean,
    var active: Boolean,
    var exercises: MutableList<WorkoutExercise>,
    val isNew: Boolean
)

private fun MainActivity.daysLabel(s: WorkoutSession): String =
    if (s.oneOffDate.isNotBlank()) s.oneOffDate else s.days.sortedBy { weekOrder.indexOf(it) }.joinToString(" · ") { dayShort(it) }

private fun MainActivity.circle(fill: Int, strokeColor: Int, label: String, labelColor: Int): TextView = TextView(this).apply {
    text = label; gravity = Gravity.CENTER; textSize = 13f; setTextColor(labelColor); setTypeface(typeface, Typeface.BOLD)
    background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(fill); if (strokeColor != 0) setStroke(dp(2), strokeColor) }
}

// ======================= WORKOUT TAB =======================
internal fun MainActivity.showWorkout() {
    val sessions = todaySessions()
    val inProg = WorkoutStore.inProgress(this)

    val hero = card(16)
    if (inProg != null) {
        hero.background = shape(amberSoft, 20)
        val cks = WorkoutStore.exerciseChecks(this, inProg.id).size
        hero.addView(text("🏋️ Sesi sedang berlangsung", 12f, true, amberDark))
        hero.addView(text(inProg.name, 20f, true))
        hero.addView(text("$cks dari ${inProg.exercises.size} gerakan selesai", 13f, false, subtle))
        hero.addView(hbar(if (inProg.exercises.isEmpty()) 0 else cks * 100 / inProg.exercises.size, amber))
        hero.addView(button("Lanjutkan sesi", true) { showWorkoutDetail(inProg.id) })
    } else if (sessions.isEmpty()) {
        hero.addView(text("😌 Hari istirahat", 18f, true))
        var nextText = "Belum ada jadwal workout. Bikin jadwal pertamamu di bawah."
        for (off in 1..7) {
            val list = WorkoutStore.sessionsForDate(this, WorkoutStore.date(off))
            if (list.isNotEmpty()) {
                val wd = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, off) }.get(Calendar.DAY_OF_WEEK)
                nextText = "Berikutnya: ${list[0].name} · ${dayShort(wd)} ${list[0].time}"
                break
            }
        }
        hero.addView(text(nextText, 13f, false, subtle))
    } else {
        hero.addView(text("Hari ini", 12f, false, subtle))
        sessions.forEach { s ->
            val finished = WorkoutStore.isDone(this, s.id)
            hero.addView(text("${s.name}${if (finished) " ✅" else ""}", 18f, true))
            hero.addView(text("${s.time} · ${s.durationMinutes} menit · ${s.exercises.size} gerakan", 13f, false, subtle))
            hero.addView(button(if (finished) "Lihat sesi" else "Mulai sesi", !finished) { showWorkoutDetail(s.id) })
        }
    }
    content.addView(hero)

    // streaks
    val wStreak = Smart.workoutStreak(stats)
    val best = maxOf(Smart.bestWorkoutStreak(stats), wStreak)
    content.addView(tileRow(
        statTile("🔥", "$wStreak", "Streak workout", "hari istirahat tidak memutus"),
        statTile("🏆", "$best", "Rekor terbaik", "hari berturut-turut")
    ))

    // week dots + weekly goal
    val target = prefs().getInt("weekly_workout_goal", 4)
    val mondayOffset = (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) + 5) % 7
    val week = card()
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    var weekDone = 0
    for (i in 0..6) {
        val off = i - mondayOffset
        val st = if (off <= 0) stats.getOrNull(stats.size - 1 + off) else null
        val scheduledFuture = off > 0 && WorkoutStore.sessionsForDate(this, WorkoutStore.date(off)).isNotEmpty()
        val isDone = st != null && st.workoutDone > 0
        if (isDone) weekDone++
        val scheduled = (st != null && st.workoutTotal > 0) || scheduledFuture
        val missed = st != null && !isDone && st.workoutTotal > 0 && off < 0
        val dot = when {
            isDone -> circle(amber, 0, "✓", Color.WHITE)
            missed -> circle(dangerSoft, 0, "✕", danger)
            scheduled -> circle(Color.WHITE, amber, "", amber)
            else -> circle(Color.parseColor("#EFEFF4"), 0, "", subtle)
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        col.addView(dot, LinearLayout.LayoutParams(dp(32), dp(32)))
        col.addView(text(dayShort(weekOrder[i]), 10f, off == 0, if (off == 0) green else subtle).apply { gravity = Gravity.CENTER })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
    }
    week.addView(text("Minggu ini", 16f, true))
    week.addView(row.apply { setPadding(0, dp(8), 0, dp(4)) })
    week.addView(text("$weekDone/$target hari aktif · ketuk untuk ubah target", 12f, false, subtle))
    week.addView(hbar(if (target == 0) 0 else (weekDone * 100 / target).coerceAtMost(100), amber))
    week.setOnClickListener {
        val e = EditText(this).apply { inputType = 2; setText(target.toString()); hint = "Hari per minggu (1–7)" }
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Target mingguan").setView(e).setPositiveButton("Simpan") { _, _ ->
            prefs().edit().putInt("weekly_workout_goal", (e.text.toString().toIntOrNull() ?: 4).coerceIn(1, 7)).apply(); render(false)
        }.setNegativeButton("Batal", null).show()
    }
    content.addView(week)

    content.addView(button("Bikin Jadwal", true) { showBuilder(null) })
    content.addView(pair(button("Program Siap Pakai") { showPrograms() }, button("Timer") { showTimer(-1L) }))

    section("Jadwal saya")
    val all = WorkoutStore.load(this)
    if (all.isEmpty()) content.addView(hint("Belum ada jadwal. Pilih program siap pakai atau bikin sendiri."))
    else {
        val list = listCard()
        all.forEach { s -> list.addView(listItem(s.name, "${daysLabel(s)} · ${s.time} · ${s.durationMinutes} menit${if (s.active) "" else " · Dijeda"}") { showWorkoutDetail(s.id) }) }
        content.addView(list)
    }
}

// ======================= SESSION DETAIL =======================
internal fun MainActivity.showWorkoutDetail(id: Long) {
    val session = WorkoutStore.load(this).find { it.id == id } ?: run { render(false); return }
    screen = "detail:$id"; onTimerScreen = false; animating = true
    content.removeAllViews(); scrollView?.scrollTo(0, 0)
    val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    bar.addView(backLink("‹ Workout") { render(true) }, LinearLayout.LayoutParams(0, -2, 1f))
    bar.addView(text("Edit", 15f, true, green).apply { setPadding(dp(12), dp(4), dp(4), dp(10)); setOnClickListener { showBuilder(session) } })
    content.addView(bar)
    content.addView(text(session.name, 26f, true))
    content.addView(text("${daysLabel(session)} · ${session.time} · ${session.durationMinutes} menit", 13f, false, subtle))
    if (session.notes.isNotBlank()) content.addView(hint(session.notes))

    val checked = WorkoutStore.exerciseChecks(this, id)
    val total = session.exercises.size
    val isDone = WorkoutStore.isDone(this, id)

    if (isDone) {
        val c = card(); c.background = shape(amberSoft, 20)
        c.addView(text("✅ Sesi selesai!", 20f, true, amberDark))
        c.addView(text("+20 EXP · Streak workout ${Smart.workoutStreak(stats)} hari 🔥", 14f, false, ink))
        content.addView(c)
    } else {
        val c = card()
        c.addView(text("${checked.size} dari $total gerakan", 14f, true))
        c.addView(hbar(if (total == 0) 0 else checked.size * 100 / total, amber))
        content.addView(c)
    }

    if (total == 0) {
        content.addView(hint("Belum ada gerakan di sesi ini. Tambahkan lewat Edit."))
        content.addView(button(if (isDone) "Batalkan status selesai" else "Tandai sesi selesai", !isDone) { WorkoutStore.setDone(this, id, !isDone); refreshData(); showWorkoutDetail(id) })
        return
    }

    val nextIndex = if (isDone) -1 else (0 until total).firstOrNull { !checked.contains(it) } ?: -1
    val list = listCard()
    session.exercises.forEachIndexed { index, ex ->
        list.addView(woRow(ex.name, "${ex.sets} set × ${ex.reps}", checked.contains(index), index == nextIndex, true, { v -> onExerciseToggled(session, index, v) }, null, { showGuide(ex.name) }))
    }
    content.addView(list)
    if (!isDone) content.addView(hint("Centang gerakan yang selesai — timer istirahat muncul otomatis, lalu lanjut ke gerakan berikutnya."))
}

private fun MainActivity.onExerciseToggled(session: WorkoutSession, index: Int, value: Boolean) {
    val id = session.id
    val next = WorkoutStore.exerciseChecks(this, id)
    if (value) next.add(index) else next.remove(index)
    WorkoutStore.saveExerciseChecks(this, id, next)
    val total = session.exercises.size
    if (value && next.size >= total) {
        WorkoutStore.setDone(this, id, true)
        handler.postDelayed({
            if (screen == "detail:$id") {
                refreshData()
                Toast.makeText(this, "Workout selesai! 🔥 Streak ${Smart.workoutStreak(stats)} hari", Toast.LENGTH_LONG).show()
                showWorkoutDetail(id)
            }
        }, 320)
    } else {
        if (!value && WorkoutStore.isDone(this, id)) WorkoutStore.setDone(this, id, false)
        handler.postDelayed({
            if (screen == "detail:$id") {
                if (value) showTimer(id) else showWorkoutDetail(id)
            }
        }, 320)
    }
}

// ======================= TIMER =======================
internal fun MainActivity.startTimer() {
    if (timerRemaining <= 0) timerRemaining = timerSet
    timerState = 1
    timerEndAt = android.os.SystemClock.elapsedRealtime() + timerRemaining * 1000
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    handler.removeCallbacks(timerTick)
    handler.post(timerTick)
}

internal fun MainActivity.pauseTimer() {
    timerState = 2
    handler.removeCallbacks(timerTick)
    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
}

internal fun MainActivity.stopTimer() {
    timerState = 0
    handler.removeCallbacks(timerTick)
    timerRemaining = timerSet
    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
}

internal fun MainActivity.showTimer(flowId: Long) {
    screen = "timer"; onTimerScreen = true; flowWorkoutId = flowId
    content.removeAllViews(); scrollView?.scrollTo(0, 0)
    content.addView(backLink("‹ Workout") { render(true) })
    content.addView(text(if (flowId >= 0) "Istirahat" else "Timer", 26f, true))
    if (flowId >= 0) {
        val s = WorkoutStore.load(this).find { it.id == flowId }
        if (s != null) {
            val checked = WorkoutStore.exerciseChecks(this, flowId)
            val nextIdx = (0 until s.exercises.size).firstOrNull { !checked.contains(it) }
            val ex = if (nextIdx != null) s.exercises[nextIdx] else null
            if (ex != null) content.addView(text("Berikutnya: ${ex.name} · ${ex.sets} set × ${ex.reps}  — ketuk untuk panduan", 14f, false, subtle).apply { setOnClickListener { showGuide(ex.name) } })
        }
    }
    val c = card(22)
    c.gravity = Gravity.CENTER_HORIZONTAL
    timerBox = c
    content.addView(c)
    buildTimerBody()
}

internal fun MainActivity.buildTimerBody() {
    val box = timerBox ?: return
    box.removeAllViews()
    timerRing = null
    if (timerState == 0) {
        val mins = WheelView(this, 99).apply { value = (timerSet / 60).toInt(); mainColor = green }
        val secs = WheelView(this, 59).apply { value = (timerSet % 60).toInt(); mainColor = green }
        val update = { _: Int ->
            val t = (mins.value * 60 + secs.value).toLong().coerceAtLeast(1L)
            timerSet = t
            timerRemaining = t
            prefs().edit().putLong("rest_seconds", t).apply()
        }
        mins.onChange = update
        secs.onChange = update
        val wheels = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        wheels.addView(mins)
        wheels.addView(text(":", 40f, true, green).apply { gravity = Gravity.CENTER })
        wheels.addView(secs)
        box.addView(wheels)
        box.addView(text("menit  ·  detik", 12f, false, subtle).apply { gravity = Gravity.CENTER })
        box.addView(hint("Gulir angka ke atas / bawah untuk mengatur waktu."))
    } else {
        val ring = RingView(this).apply {
            segs = listOf(RingView.Seg(amber, timerSet.toInt(), (timerSet - timerRemaining).toInt()))
            centerText = formatTime(timerRemaining)
            centerSub = if (timerState == 1) "berjalan" else "dijeda"
        }
        timerRing = ring
        box.addView(ring, LinearLayout.LayoutParams(dp(220), dp(220)))
    }
    val label = when (timerState) { 0 -> "Mulai"; 1 -> "Jeda"; else -> "Lanjut" }
    val primary = button(label, true) {
        when (timerState) {
            0 -> startTimer()
            1 -> pauseTimer()
            else -> startTimer()
        }
        buildTimerBody()
    }
    if (timerState == 0) {
        box.addView(primary)
    } else {
        val stop = button("Berhenti") { stopTimer(); buildTimerBody() }
        box.addView(pair(stop, primary), LinearLayout.LayoutParams(-1, -2))
    }
}

// ======================= PROGRAMS =======================
internal fun MainActivity.showPrograms() {
    screen = "programs"; onTimerScreen = false
    content.removeAllViews(); scrollView?.scrollTo(0, 0)
    content.addView(backLink("‹ Workout") { render(true) })
    content.addView(text("Program siap pakai", 26f, true))
    content.addView(hint("Pilih program, lihat isinya, lalu pakai dengan satu ketukan. Semua bisa diubah nanti."))
    Programs.all.forEach { p ->
        val c = card()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(text(p.emoji, 28f).apply { setPadding(0, 0, dp(12), 0) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(p.name, 16f, true))
        val perWeek = p.sessions.sumOf { it.days.size }
        col.addView(text("${p.level} · $perWeek sesi/minggu · ${p.sessions.map { it.duration }.minOrNull() ?: 0}–${p.sessions.map { it.duration }.maxOrNull() ?: 0} menit", 12f, false, subtle))
        top.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(chevron(), LinearLayout.LayoutParams(dp(18), dp(18)))
        c.addView(top)
        c.addView(text(p.desc, 13f, false, ink).apply { setPadding(dp(2), dp(8), dp(2), dp(2)) })
        c.setOnClickListener { showProgramDialog(p) }
        content.addView(c)
    }
}

private fun MainActivity.showProgramDialog(p: ReadyProgram) {
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
    box.addView(text(p.desc, 13f, false, subtle))
    box.addView(text("Ketuk nama gerakan untuk melihat panduannya.", 12f, true, green).apply { setPadding(dp(2), dp(8), dp(2), dp(2)) })
    p.sessions.forEach { ps ->
        box.addView(text("${ps.name} · ${ps.days.sortedBy { weekOrder.indexOf(it) }.joinToString(" ") { dayShort(it) }} · ${ps.duration} mnt", 14f, true).apply { setPadding(dp(2), dp(12), dp(2), dp(2)) })
        ps.exercises.forEach { ex -> box.addView(text("• ${ex.name} — ${ex.sets} × ${ex.reps}", 13f, false, ink).apply { setPadding(dp(2), dp(5), dp(2), dp(5)); setOnClickListener { showGuide(ex.name) } }) }
    }
    AlertDialog.Builder(this, R.style.RillDialog).setTitle("${p.emoji} ${p.name}").setView(ScrollView(this).apply { addView(box) })
        .setPositiveButton("Pakai program") { _, _ -> applyProgram(p, p.time) }
        .setNeutralButton("Pilih jam…") { _, _ ->
            val parts = p.time.split(":")
            TimePickerDialog(this, { _, h, m -> applyProgram(p, String.format(Locale.US, "%02d:%02d", h, m)) }, parts[0].toInt(), parts[1].toInt(), true).show()
        }
        .setNegativeButton("Tutup", null).show()
}

private fun MainActivity.applyProgram(p: ReadyProgram, time: String) {
    val all = WorkoutStore.load(this)
    p.sessions.forEachIndexed { i, ps ->
        all.add(WorkoutSession(System.currentTimeMillis() + i, ps.name, time, ps.duration, ps.days.toMutableSet(), "", p.desc, false, true, ps.exercises.map { WorkoutExercise(it.name, it.sets, it.reps) }.toMutableList()))
    }
    WorkoutStore.save(this, all)
    ReminderScheduler.scheduleAll(this)
    Toast.makeText(this, "${p.name} ditambahkan ke Jadwal saya ✓", Toast.LENGTH_LONG).show()
    selectedTab = "Workout"
    render(true)
}

// ======================= BIKIN JADWAL (builder) =======================
internal fun MainActivity.showBuilder(existing: WorkoutSession?) {
    draft = if (existing == null) {
        Draft(System.currentTimeMillis(), "", "18:00", 30, mutableSetOf(Calendar.MONDAY, Calendar.WEDNESDAY, Calendar.FRIDAY), "", "", false, true, mutableListOf(), true)
    } else {
        Draft(existing.id, existing.name, existing.time, existing.durationMinutes, existing.days.toMutableSet(), existing.oneOffDate, existing.notes, existing.reminder, existing.active, existing.exercises.map { WorkoutExercise(it.name, it.sets, it.reps) }.toMutableList(), false)
    }
    scrollView?.scrollTo(0, 0)
    renderBuilder()
}

internal fun MainActivity.renderBuilder() {
    val d = draft ?: return
    val keepY = scrollView?.scrollY ?: 0
    screen = "builder"; onTimerScreen = false
    content.removeAllViews()
    content.addView(backLink("‹ Batal") { draft = null; render(true) })
    content.addView(text(if (d.isNew) "Bikin Jadwal" else "Edit Jadwal", 26f, true))

    // name
    val c1 = card()
    c1.addView(text("Nama sesi", 13f, true, subtle))
    val nameField = EditText(this).apply { hint = "Contoh: Push Day"; setText(d.name); setSingleLine(true) }
    nameField.addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(s: Editable?) { d.name = s?.toString() ?: "" }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    })
    c1.addView(nameField)
    content.addView(c1)

    // days
    val c2 = card()
    c2.addView(text("Hari", 13f, true, subtle))
    if (d.oneOffDate.isNotBlank()) c2.addView(hint("📅 Sekali jalan pada ${d.oneOffDate}. Pilih hari di bawah untuk mengubahnya jadi berulang."))
    val dayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, dp(6)) }
    weekOrder.forEach { wd ->
        val sel = d.days.contains(wd)
        val t = TextView(this).apply {
            text = dayShort(wd); gravity = Gravity.CENTER; textSize = 12f
            setTextColor(if (sel) Color.WHITE else ink)
            if (sel) setTypeface(typeface, Typeface.BOLD)
            background = shape(if (sel) green else Color.parseColor("#EFEFF4"), 14)
            setPadding(0, dp(11), 0, dp(11))
            setOnClickListener { if (sel) d.days.remove(wd) else d.days.add(wd); d.oneOffDate = ""; renderBuilder() }
        }
        dayRow.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
    }
    c2.addView(dayRow)
    val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    quick.addView(chip("Tiap hari", false) { d.days = weekOrder.toMutableSet(); d.oneOffDate = ""; renderBuilder() }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(6), 0) })
    quick.addView(chip("Sen–Jum", false) { d.days = weekOrder.take(5).toMutableSet(); d.oneOffDate = ""; renderBuilder() }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(6), 0) })
    quick.addView(chip("Sen · Rab · Jum", false) { d.days = mutableSetOf(Calendar.MONDAY, Calendar.WEDNESDAY, Calendar.FRIDAY); d.oneOffDate = ""; renderBuilder() })
    c2.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(quick) })
    content.addView(c2)

    // time + duration
    val c3 = card()
    c3.addView(text("Jam & durasi", 13f, true, subtle))
    val timeBtn = TextView(this).apply {
        text = "🕒  ${d.time}"; textSize = 22f; setTypeface(typeface, Typeface.BOLD); setTextColor(green); gravity = Gravity.CENTER
        background = shape(greenSoft, 14); setPadding(0, dp(14), 0, dp(14))
        setOnClickListener {
            val p = d.time.split(":")
            TimePickerDialog(this@renderBuilder, { _, h, m -> d.time = String.format(Locale.US, "%02d:%02d", h, m); renderBuilder() }, p.getOrNull(0)?.toIntOrNull() ?: 18, p.getOrNull(1)?.toIntOrNull() ?: 0, true).show()
        }
    }
    c3.addView(timeBtn, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, dp(8)) })
    val durRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    listOf(15, 30, 45, 60, 90).forEach { m ->
        durRow.addView(chip("$m mnt", d.duration == m) { d.duration = m; renderBuilder() }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(6), 0) })
    }
    c3.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(durRow) })
    content.addView(c3)

    // exercises
    val c4 = card()
    c4.addView(text("Gerakan (${d.exercises.size})", 13f, true, subtle))
    if (d.exercises.isEmpty()) c4.addView(hint("Belum ada gerakan. Tambahkan satu per satu, atau ambil dari program siap pakai."))
    d.exercises.forEachIndexed { i, ex -> c4.addView(listItem("${i + 1}. ${ex.name}", "${ex.sets} set × ${ex.reps}") { editExerciseDialog(d, i) }) }
    c4.addView(button("+ Tambah gerakan") { showExercisePicker(d) })
    c4.addView(button("Ambil dari program siap pakai") { showSessionPicker(d) })
    content.addView(c4)

    // reminder
    val c5 = card()
    val rem = CheckBox(this).apply { text = "Ingatkan saya di jam ini"; isChecked = d.reminder; setOnCheckedChangeListener { _, v -> d.reminder = v } }
    c5.addView(rem)
    content.addView(c5)

    content.addView(button("Simpan jadwal", true) { saveDraft(d) })
    if (!d.isNew) {
        content.addView(pair(
            button(if (d.active) "Jeda program" else "Aktifkan program") { d.active = !d.active; renderBuilder() },
            button("Hapus") {
                AlertDialog.Builder(this@renderBuilder, R.style.RillDialog).setTitle("Hapus jadwal?").setMessage("\"${d.name}\" akan dihapus permanen.").setPositiveButton("Hapus") { _, _ ->
                    val all = WorkoutStore.load(this@renderBuilder)
                    all.removeAll { it.id == d.id }
                    WorkoutStore.save(this@renderBuilder, all)
                    ReminderScheduler.scheduleAll(this@renderBuilder)
                    draft = null; selectedTab = "Workout"; render(true)
                }.setNegativeButton("Batal", null).show()
            }
        ))
    }
    scrollView?.post { scrollView?.scrollTo(0, keepY) }
}

private fun MainActivity.saveDraft(d: Draft) {
    val name = d.name.trim()
    if (name.isEmpty()) { Toast.makeText(this, "Beri nama sesi dulu.", Toast.LENGTH_SHORT).show(); return }
    if (d.days.isEmpty() && d.oneOffDate.isBlank()) { Toast.makeText(this, "Pilih minimal satu hari.", Toast.LENGTH_SHORT).show(); return }
    if (d.exercises.isEmpty()) { Toast.makeText(this, "Tambahkan minimal satu gerakan.", Toast.LENGTH_SHORT).show(); return }
    val s = WorkoutSession(d.id, name, d.time, d.duration, d.days.toMutableSet(), d.oneOffDate, d.notes, d.reminder, d.active, d.exercises.map { WorkoutExercise(it.name, it.sets, it.reps) }.toMutableList())
    val all = WorkoutStore.load(this)
    val idx = all.indexOfFirst { it.id == s.id }
    if (idx >= 0) all[idx] = s else all.add(s)
    WorkoutStore.save(this, all)
    ReminderScheduler.scheduleAll(this)
    Toast.makeText(this, "Jadwal tersimpan ✓", Toast.LENGTH_SHORT).show()
    draft = null; selectedTab = "Workout"; render(true)
}

private fun MainActivity.showExercisePicker(d: Draft) {
    val names = Programs.library.map { it.name } + "✍️ Tulis sendiri…"
    val adapter = object : BaseAdapter() {
        override fun getCount(): Int = names.size
        override fun getItem(position: Int): Any = names[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = LinearLayout(this@showExercisePicker).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(12), dp(14), dp(12)) }
            row.addView(text(names[position], 16f, false, ink), LinearLayout.LayoutParams(0, -2, 1f))
            if (position < Programs.library.size) {
                val guide = TextView(this@showExercisePicker).apply { text = "Panduan"; textSize = 12f; setTextColor(green); background = shape(greenSoft, 12); setPadding(dp(10), dp(5), dp(10), dp(5)) }
                guide.setOnClickListener { showGuide(names[position]) }
                row.addView(guide)
            }
            return row
        }
    }
    AlertDialog.Builder(this, R.style.RillDialog).setTitle("Pilih gerakan").setAdapter(adapter) { _, which ->
        if (which < Programs.library.size) {
            val src = Programs.library[which]
            d.exercises.add(WorkoutExercise(src.name, src.sets, src.reps))
            renderBuilder()
        } else editExerciseDialog(d, -1)
    }.setNegativeButton("Batal", null).show()
}

private fun MainActivity.editExerciseDialog(d: Draft, index: Int) {
    val ex = if (index >= 0) d.exercises[index] else WorkoutExercise("", 3, "10")
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
    val name = EditText(this).apply { hint = "Nama gerakan"; setText(ex.name) }
    val sets = EditText(this).apply { hint = "Jumlah set"; inputType = 2; setText(ex.sets.toString()) }
    val reps = EditText(this).apply { hint = "Repetisi / durasi (contoh: 10 atau 30 detik)"; setText(ex.reps) }
    box.addView(name); box.addView(sets); box.addView(reps)
    val guideLink = text("Lihat panduan gerakan ›", 13f, true, green).apply { setPadding(dp(2), dp(10), dp(2), dp(6)) }
    guideLink.setOnClickListener { showGuide(name.text.toString().ifBlank { ex.name.ifBlank { "gerakan" } }) }
    box.addView(guideLink)
    val b = AlertDialog.Builder(this, R.style.RillDialog).setTitle(if (index >= 0) "Edit gerakan" else "Gerakan baru").setView(box)
    b.setPositiveButton("Simpan") { _, _ ->
        if (name.text.isNullOrBlank()) { Toast.makeText(this, "Isi nama gerakan.", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
        ex.name = name.text.toString().trim()
        ex.sets = (sets.text.toString().toIntOrNull() ?: 3).coerceIn(1, 20)
        ex.reps = reps.text.toString().trim().ifBlank { "10" }
        if (index < 0) d.exercises.add(ex)
        renderBuilder()
    }
    if (index >= 0) b.setNeutralButton("Hapus") { _, _ -> d.exercises.removeAt(index); renderBuilder() }
    b.setNegativeButton("Batal", null).show()
}

private fun MainActivity.showSessionPicker(d: Draft) {
    val labels = ArrayList<String>()
    val pairs = ArrayList<Pair<ReadyProgram, ProgSession>>()
    Programs.all.forEach { p -> p.sessions.forEach { s -> labels.add("${p.emoji} ${p.name} · ${s.name}"); pairs.add(Pair(p, s)) } }
    AlertDialog.Builder(this, R.style.RillDialog).setTitle("Ambil dari program").setItems(labels.toTypedArray()) { _, which ->
        val (p, s) = pairs[which]
        if (d.name.isBlank()) d.name = s.name
        d.days = s.days.toMutableSet()
        d.oneOffDate = ""
        d.duration = s.duration
        d.exercises = s.exercises.map { WorkoutExercise(it.name, it.sets, it.reps) }.toMutableList()
        if (d.isNew) d.time = p.time
        renderBuilder()
    }.setNegativeButton("Batal", null).show()
}
