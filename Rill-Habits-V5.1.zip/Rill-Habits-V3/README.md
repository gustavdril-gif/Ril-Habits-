# Rill Habits V4 — iOS-style Minimal + Smart

Rill Habits V3 is a visual redesign of the V2 Android app. The intent is an iOS-inspired, warm, minimal interface using cream and sage green, with a sprout identity and persistent bottom navigation. Existing V2 task/workout logic and local data stores are retained as the foundation.

## Design direction
- Light grey-lavender background (#F2F2F7), white rounded cards (20dp), forest green (#2F6F4F) accent, iOS-style floating pill bottom navigation with icons.
- Persistent five-item bottom navigation: Beranda, Habit, Workout, Jadwal, Progres.
- Rounded cards, understated controls, no heavy animations or remote assets.
- Native Android UI to keep runtime overhead low for Android 10 / 2 GB RAM devices.
- APK size target: <= 10 MB; this must be checked on the actual build artifact.

## Features inherited from V2
- Daily checklist, XP/levels, Daily Note, mood tracking and review.
- Workout schedules, repeat days, ready-made programs, exercise checks, timer and streaks.
- Local reminders and local data storage.
- Existing application ID `com.airil.rillrebirth` retained to preserve update compatibility. Note: installing an APK with the same application ID but a different signing key cannot update an existing installation; do not uninstall V2 if you need its local data.

## Build on GitHub Actions
1. Upload the contents of this project folder to the root of a new repository named `Rill-Habits-V3`.
2. Open **Actions** and run **Build Rill Habits V3 APK**.
3. Download artifact `Rill-Habits-V3-debug-APK` from the completed workflow run.
4. Install and test on the target Redmi 8A Pro (Android 10).

## Verification status
This source package is prepared for GitHub Actions, but has not yet been compiled or device-tested here. Treat build success, feature regression checks, and the 10 MB APK size limit as open verification tasks until the workflow completes.


## V4 highlights
- 3-colour progress ring (Ibadah / Workout / Lainnya), dynamic Beranda, level-up and smart suggestions.
- Workout: in-progress session, rest-day-aware streak, week dots, auto rest timer (scroll-wheel, loud TET alarm), 'Bikin Jadwal' builder, 10 ready programs.
- Statistik: consistency bars, 12-week heatmap, category rates, mood curve (week/month/year), smart insights.
- Mood (emoji + tags) and evening review appear only after everything for the day is done.
- Animations: 0.5 s entrance/progress, 0.2 s tap feedback. Pure framework Views, no extra libraries.
