package com.airil.rillrebirth

import android.app.AlertDialog
import android.content.Context
import android.graphics.Paint
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** A short note ("Catatan") that expires on its own. expires == 0 means it never expires. */
data class NoteItem(val id: Long, var text: String, var expires: Long, var done: Boolean)

object NoteStore {
    private const val KEY = "notes_json"
    private const val MIGRATED = "notes_migrated_v1"

    private fun prefs(c: Context) = c.getSharedPreferences("rill_data", Context.MODE_PRIVATE)

    /** Last millisecond of the day that is [daysFromToday] days from now (0 = today). */
    fun endOfDay(daysFromToday: Int): Long {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, daysFromToday)
        cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59); cal.set(Calendar.MILLISECOND, 999)
        return cal.timeInMillis
    }

    fun load(c: Context): MutableList<NoteItem> {
        val p = prefs(c)
        if (!p.getBoolean(MIGRATED, false)) migrateDailyNote(c)
        val arr = try { JSONArray(p.getString(KEY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val now = System.currentTimeMillis()
        val list = mutableListOf<NoteItem>()
        var purged = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val exp = o.optLong("expires", 0L)
            if (exp > 0L && exp < now) { purged = true; continue }
            list.add(NoteItem(o.optLong("id"), o.optString("text"), exp, o.optBoolean("done", false)))
        }
        if (purged) save(c, list)
        return list
    }

    fun save(c: Context, list: List<NoteItem>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("expires", it.expires).put("done", it.done)) }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }

    fun sorted(list: List<NoteItem>): List<NoteItem> =
        list.sortedWith(compareBy<NoteItem>({ it.done }, { if (it.expires == 0L) Long.MAX_VALUE else it.expires }))

    /** One-time: today's old Daily Note becomes a note that lasts until the end of today. */
    private fun migrateDailyNote(c: Context) {
        val p = prefs(c)
        val old = (p.getString("daily_note_${TaskStore.today()}", "") ?: "").trim()
        if (old.isNotEmpty()) save(c, listOf(NoteItem(System.currentTimeMillis(), old, endOfDay(0), false)))
        p.edit().putBoolean(MIGRATED, true).apply()
    }
}

/** Whole days between today and the day the note ends (0 = ends today). */
internal fun noteDiffDays(n: NoteItem): Int {
    val a = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    val b = Calendar.getInstance().apply { timeInMillis = n.expires; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    return Math.round((b.timeInMillis - a.timeInMillis) / 86400000.0).toInt()
}

/** Label + whether it is urgent (ends today). */
internal fun noteExpiry(n: NoteItem): Pair<String, Boolean> {
    if (n.expires == 0L) return Pair("Tanpa batas waktu", false)
    val diff = noteDiffDays(n)
    return when {
        diff <= 0 -> Pair("Berakhir hari ini", true)
        diff == 1 -> Pair("Berakhir besok", false)
        else -> Pair("Berakhir $diff hari lagi", false)
    }
}

private fun MainActivity.afterNoteChange() {
    if (screen == "notes") showNotes() else render(false)
}

private fun MainActivity.thinDivider(): View = View(this).apply {
    setBackgroundColor(line)
    layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { setMargins(dp(4), 0, dp(4), 0) }
}

private fun MainActivity.noteRow(n: NoteItem): LinearLayout {
    val (exLabel, urgent) = noteExpiry(n)
    val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(10), dp(4), dp(10)) }
    val cb = CheckBox(this).apply { setButtonDrawable(R.drawable.cb_selector); setPadding(0, 0, 0, 0); minWidth = 0; minHeight = 0; isChecked = n.done }
    r.addView(cb, LinearLayout.LayoutParams(dp(26), dp(26)))
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(4), 0) }
    val title = text(n.text, 15f, false, if (n.done) subtle else ink).apply {
        maxLines = 3; ellipsize = TextUtils.TruncateAt.END
        if (n.done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
    }
    col.addView(title)
    col.addView(text(if (n.done) "Selesai · $exLabel" else exLabel, 11f, false, if (urgent && !n.done) danger else subtle))
    r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
    cb.setOnCheckedChangeListener { _, v ->
        n.done = v
        NoteStore.save(this, notes)
        handler.postDelayed({ afterNoteChange() }, 220)
    }
    r.setOnClickListener { editNote(n) }
    return r
}

/** Home card: sits right under the progress card. */
internal fun MainActivity.notesCard() {
    val c = card(12)
    val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    head.addView(text("📝 Catatan", 16f, true), LinearLayout.LayoutParams(0, -2, 1f))
    head.addView(text("+ Tambah", 13f, true, green).apply {
        setPadding(dp(12), dp(6), dp(12), dp(6)); background = shape(greenSoft, 14)
        setOnClickListener { editNote(null) }
    })
    c.addView(head)
    val list = NoteStore.sorted(notes)
    if (list.isEmpty()) {
        c.addView(hint("Belum ada catatan. Tulis hal yang harus dikerjakan atau diingat — kamu yang atur berapa lama bertahan."))
    } else {
        val shown = list.take(4)
        shown.forEachIndexed { i, n -> c.addView(noteRow(n)); if (i < shown.size - 1) c.addView(thinDivider()) }
        if (list.size > 4) c.addView(button("Lihat semua (${list.size})") { showNotes() })
    }
    content.addView(c)
}

/** Full list of notes. */
internal fun MainActivity.showNotes() {
    screen = "notes"; onTimerScreen = false; animating = true
    applyBackdrop(false)
    content.removeAllViews(); scrollView?.scrollTo(0, 0)
    content.addView(backLink("‹ Beranda") { render(true) })
    content.addView(text("Catatan", 28f, true))
    content.addView(hint("Catatan hilang otomatis setelah masa berlakunya habis."))
    val list = NoteStore.sorted(notes)
    if (list.isEmpty()) content.addView(hint("Belum ada catatan."))
    else {
        val card = listCard()
        list.forEachIndexed { i, n -> card.addView(noteRow(n)); if (i < list.size - 1) card.addView(thinDivider()) }
        content.addView(card)
    }
    content.addView(button("+ Tambah catatan", true) { editNote(null) })
}

internal fun MainActivity.editNote(existing: NoteItem?) {
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(4)) }
    val input = EditText(this).apply {
        hint = "Apa yang harus dikerjakan atau diingat?"; minLines = 3; gravity = Gravity.TOP
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        setText(existing?.text ?: "")
    }
    val prefill = if (existing == null) "3" else if (existing.expires == 0L) "" else (noteDiffDays(existing) + 1).coerceAtLeast(1).toString()
    val daysField = EditText(this).apply { hint = "Bertahan berapa hari? (kosong = tanpa batas)"; inputType = InputType.TYPE_CLASS_NUMBER; setText(prefill) }
    val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, dp(4)) }
    listOf("Hari ini" to "1", "3 hari" to "3", "1 minggu" to "7", "1 bulan" to "30", "Selamanya" to "").forEach { (label, v) ->
        chips.addView(chip(label, false) { daysField.setText(v); daysField.setSelection(daysField.text.length) }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(6), 0) })
    }
    box.addView(input)
    box.addView(text("Lama bertahan", 13f, true, subtle).apply { setPadding(dp(2), dp(12), dp(2), dp(2)) })
    box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })
    box.addView(daysField)
    AlertDialog.Builder(this, R.style.RillDialog).setTitle(if (existing == null) "Catatan baru" else "Edit catatan")
        .setView(android.widget.ScrollView(this).apply { addView(box) })
        .setPositiveButton("Simpan") { _, _ ->
            val t = input.text.toString().trim()
            if (t.isEmpty()) { Toast.makeText(this, "Tulis dulu isi catatannya.", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
            val raw = daysField.text.toString().trim()
            val days = raw.toIntOrNull()
            val expires = if (days == null || days <= 0) 0L else NoteStore.endOfDay(days.coerceAtMost(3650) - 1)
            if (existing == null) notes.add(NoteItem(System.currentTimeMillis(), t, expires, false))
            else { existing.text = t; if (raw != prefill) existing.expires = expires }
            NoteStore.save(this, notes)
            afterNoteChange()
        }
        .setNeutralButton(if (existing != null) "Hapus" else "Batal") { _, _ ->
            if (existing != null) { notes.removeAll { it.id == existing.id }; NoteStore.save(this, notes); afterNoteChange() }
        }
        .setNegativeButton("Tutup", null).show()
}
