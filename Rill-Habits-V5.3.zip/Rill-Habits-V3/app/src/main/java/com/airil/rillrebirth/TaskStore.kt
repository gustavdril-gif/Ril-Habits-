package com.airil.rillrebirth

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class RillTask(
    val id: Int,
    var name: String,
    var time: String,
    var category: String,
    var xp: Int,
    var reminderEnabled: Boolean = false,
    /** Calendar.DAY_OF_WEEK values this task runs on. Empty = every day. */
    var days: MutableSet<Int> = mutableSetOf(),
    /** "" or subuh/dzuhur/ashar/maghrib/isya: the task time then follows that prayer time of the chosen city. */
    var prayer: String = ""
) {
    fun runsOn(dow: Int): Boolean = days.isEmpty() || days.size >= 7 || days.contains(dow)
}

object TaskStore {
    private const val PREFS = "rill_data"
    private const val TASKS = "tasks_json"
    private const val DONE = "done_json"
    private const val HISTORY = "history_json"
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun today(): String = dateFmt.format(Date())

    fun load(context: Context): MutableList<RillTask> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(TASKS, null)
        if (raw == null) {
            val defaults = mutableListOf(
                RillTask(1, "Ibadah dan persiapan diri", "05:15", "Ibadah", 20, false),
                RillTask(2, "Sarapan dan persiapan sekolah", "06:00", "Rutinitas", 10, false, mutableSetOf(2, 3, 4, 5, 6)),
                RillTask(3, "Menyelesaikan tugas sekolah", "15:30", "Belajar", 20, false),
                RillTask(4, "Belajar mandiri 25 menit", "16:00", "Belajar", 20, false),
                RillTask(5, "Olahraga ringan / jogging", "16:30", "Olahraga", 20, false),
                RillTask(6, "Pengembangan diri", "19:00", "Pengembangan diri", 20, false),
                RillTask(7, "Evaluasi harian", "21:00", "Refleksi", 10, false),
                RillTask(8, "Siapkan kebutuhan besok", "21:15", "Rutinitas", 10, false),
                RillTask(9, "Sarapan", "07:00", "Rutinitas", 10, false, mutableSetOf(1, 7))
            )
            save(context, defaults)
            return defaults
        }
        val arr = JSONArray(raw)
        val list = mutableListOf<RillTask>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(RillTask(o.getInt("id"), o.getString("name"), o.getString("time"),
                o.optString("category", "Umum"), o.optInt("xp", 10), o.optBoolean("reminder", false), readDays(o), o.optString("prayer", "")))
        }
        return list
    }

    private fun readDays(o: JSONObject): MutableSet<Int> {
        val out = mutableSetOf<Int>()
        val a = o.optJSONArray("days") ?: return out
        for (j in 0 until a.length()) { val v = a.optInt(j); if (v in 1..7) out.add(v) }
        return out
    }

    fun save(context: Context, tasks: List<RillTask>) {
        val arr = JSONArray()
        tasks.forEach { t ->
            arr.put(JSONObject().put("id", t.id).put("name", t.name).put("time", t.time)
                .put("category", t.category).put("xp", t.xp).put("reminder", t.reminderEnabled).put("days", JSONArray(t.days.sorted())).put("prayer", t.prayer))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(TASKS, arr.toString()).apply()
    }

    fun doneToday(context: Context): MutableSet<Int> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val root = JSONObject(prefs.getString(DONE, "{}") ?: "{}")
        val arr = root.optJSONArray(today()) ?: JSONArray()
        val out = mutableSetOf<Int>()
        for (i in 0 until arr.length()) out.add(arr.optInt(i))
        return out
    }

    fun saveDone(context: Context, done: Set<Int>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val root = JSONObject(prefs.getString(DONE, "{}") ?: "{}")
        val arr = JSONArray()
        done.sorted().forEach { arr.put(it) }
        root.put(today(), arr)
        prefs.edit().putString(DONE, root.toString()).apply()
        val history = JSONObject(prefs.getString(HISTORY, "{}") ?: "{}")
        history.put(today(), JSONObject().put("completed", done.size).put("xp", xpFor(context, done)))
        prefs.edit().putString(HISTORY, history.toString()).apply()
    }

    fun allDone(context: Context): JSONObject = JSONObject(
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(DONE, "{}") ?: "{}"
    )

    fun xpFor(context: Context, done: Set<Int>): Int = load(context).filter { done.contains(it.id) }.sumOf { it.xp }

    fun totalXp(context: Context): Int {
        val root = allDone(context)
        val tasks = load(context)
        var total = 0
        val keys = root.keys()
        while (keys.hasNext()) {
            val date = keys.next()
            val arr = root.optJSONArray(date) ?: continue
            for (i in 0 until arr.length()) {
                val id = arr.optInt(i)
                total += tasks.find { it.id == id }?.xp ?: 10
            }
        }
        return total
    }

    fun weeklyCounts(context: Context): List<Pair<String, Int>> {
        val root = allDone(context)
        val result = mutableListOf<Pair<String, Int>>()
        val cal = java.util.Calendar.getInstance()
        for (offset in 6 downTo 0) {
            cal.time = Date()
            cal.add(java.util.Calendar.DAY_OF_YEAR, -offset)
            val key = dateFmt.format(cal.time)
            result.add(key to (root.optJSONArray(key)?.length() ?: 0))
        }
        return result
    }

    fun historySummary(context: Context): List<String> {
        val root = allDone(context)
        val keys = mutableListOf<String>()
        val it = root.keys()
        while (it.hasNext()) keys.add(it.next())
        return keys.sortedDescending().take(14).map { date ->
            val arr = root.optJSONArray(date) ?: JSONArray()
            "$date — ${arr.length()} kegiatan selesai"
        }
    }
}
