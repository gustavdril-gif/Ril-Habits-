package com.airil.rillrebirth

import android.animation.ArgbEvaluator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * Animated sky scene for the Home screen. phase: 0 pagi, 1 siang, 2 sore, 3 malam.
 * The sun/moon sits where it would be at the current hour; clouds drift and stars twinkle.
 */
class SkyView(context: Context, private val phase: Int, private val hour: Float) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val hill1 = Path()
    private val hill2 = Path()
    private var bgShader: Shader? = null
    private var scrimShader: Shader? = null
    private var glowShader: Shader? = null
    private var bodyX = 0f
    private var bodyY = 0f
    private var bodyColor = Color.WHITE
    private val starData = FloatArray(STARS * 4)

    init {
        val r = java.util.Random(11)
        for (i in 0 until STARS) {
            starData[i * 4] = r.nextFloat()
            starData[i * 4 + 1] = r.nextFloat() * 0.62f
            starData[i * 4 + 2] = 0.6f + r.nextFloat() * 1.1f
            starData[i * 4 + 3] = r.nextFloat() * 6.28f
        }
    }

    companion object {
        private const val STARS = 45
        private val CLOUD_BASE = floatArrayOf(0.05f, 0.42f, 0.78f)

        fun lightText(phase: Int): Boolean = phase >= 2
        fun darkInk(phase: Int): Int = if (phase == 0) 0xFF3B2A1E.toInt() else 0xFF0F2F57.toInt()
        fun tint(phase: Int): Int = when (phase) {
            0 -> 0xFFFFF5E8.toInt()
            1 -> 0xFFEAF4FC.toInt()
            2 -> 0xFFFDEFE7.toInt()
            else -> 0xFFE8EAF4.toInt()
        }
        private fun gradient(phase: Int): IntArray = when (phase) {
            0 -> intArrayOf(0xFF8EC9F2.toInt(), 0xFFFFE3C2.toInt())
            1 -> intArrayOf(0xFF5AB0F0.toInt(), 0xFFCFEBFB.toInt())
            2 -> intArrayOf(0xFF46479A.toInt(), 0xFFE9798A.toInt(), 0xFFFFB37A.toInt())
            else -> intArrayOf(0xFF0A1233.toInt(), 0xFF27337A.toInt())
        }
        private fun hillBack(phase: Int): Int = when (phase) {
            0 -> 0xFFA8D5A2.toInt(); 1 -> 0xFF86CB83.toInt(); 2 -> 0xFF5A4A8A.toInt(); else -> 0xFF131B45.toInt()
        }
        private fun hillFront(phase: Int): Int = when (phase) {
            0 -> 0xFF8CC68A.toInt(); 1 -> 0xFF63B36C.toInt(); 2 -> 0xFF3D3470.toInt(); else -> 0xFF0B1130.toInt()
        }
        private fun cloudAlpha(phase: Int): Int = when (phase) { 0 -> 235; 1 -> 240; 2 -> 80; else -> 26 }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val wf = w.toFloat(); val hf = h.toFloat()
        clip.reset(); clip.addRoundRect(RectF(0f, 0f, wf, hf), 28 * d, 28 * d, Path.Direction.CW)
        bgShader = LinearGradient(0f, 0f, 0f, hf, gradient(phase), null, Shader.TileMode.CLAMP)
        scrimShader = LinearGradient(0f, hf * 0.35f, 0f, hf, 0x00000000, 0x66000000, Shader.TileMode.CLAMP)
        val glowBase: Int
        if (phase == 3) {
            val n = (((hour - 18f) + 24f) % 24f / 12f).coerceIn(0f, 1f)
            bodyX = wf * (0.62f + 0.26f * n)
            bodyY = hf * (0.50f - 0.28f * sin(PI * n).toFloat())
            bodyColor = 0xFFFFF4D6.toInt()
            glowBase = 0xFFFFF3C4.toInt()
        } else {
            val f = ((hour - 5f) / 13f).coerceIn(0f, 1f)
            val elev = sin(PI * f).toFloat()
            bodyX = wf * (0.62f + 0.26f * f)
            bodyY = hf * (0.58f - 0.34f * elev)
            bodyColor = ArgbEvaluator().evaluate(elev, 0xFFFF8A3D.toInt(), 0xFFFFE066.toInt()) as Int
            glowBase = bodyColor
        }
        glowShader = RadialGradient(bodyX, bodyY, 70 * d, (glowBase and 0x00FFFFFF) or 0x77000000, glowBase and 0x00FFFFFF, Shader.TileMode.CLAMP)
        hill1.reset(); hill1.moveTo(0f, hf * 0.80f)
        hill1.quadTo(wf * 0.25f, hf * 0.62f, wf * 0.55f, hf * 0.78f)
        hill1.quadTo(wf * 0.80f, hf * 0.90f, wf, hf * 0.72f)
        hill1.lineTo(wf, hf); hill1.lineTo(0f, hf); hill1.close()
        hill2.reset(); hill2.moveTo(0f, hf * 0.90f)
        hill2.quadTo(wf * 0.30f, hf * 0.78f, wf * 0.65f, hf * 0.90f)
        hill2.quadTo(wf * 0.85f, hf * 0.96f, wf, hf * 0.86f)
        hill2.lineTo(wf, hf); hill2.lineTo(0f, hf); hill2.close()
    }

    private fun cloud(c: Canvas, x: Float, y: Float, s: Float, alpha: Int) {
        p.color = Color.argb(alpha, 255, 255, 255)
        c.drawCircle(x + s * 0.30f, y, s * 0.34f, p)
        c.drawCircle(x + s * 0.62f, y - s * 0.18f, s * 0.42f, p)
        c.drawCircle(x + s * 1.00f, y, s * 0.32f, p)
        c.drawRoundRect(x, y - s * 0.04f, x + s * 1.3f, y + s * 0.3f, s * 0.15f, s * 0.15f, p)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val time = SystemClock.uptimeMillis() / 1000f
        c.save(); c.clipPath(clip)
        p.shader = bgShader; c.drawRect(0f, 0f, w, h, p); p.shader = null
        if (phase == 3) {
            for (i in 0 until STARS) {
                val tw = 0.45f + 0.55f * abs(sin(time * (0.6f + (i % 5) * 0.25f) + starData[i * 4 + 3]))
                p.color = Color.argb((255 * tw).toInt(), 255, 255, 255)
                c.drawCircle(starData[i * 4] * w, starData[i * 4 + 1] * h, starData[i * 4 + 2] * d, p)
            }
        }
        p.shader = glowShader; c.drawCircle(bodyX, bodyY, 70 * d, p); p.shader = null
        p.color = bodyColor; c.drawCircle(bodyX, bodyY, (if (phase == 3) 17 else 22) * d, p)
        if (phase == 3) {
            p.color = 0x22B8A97A
            c.drawCircle(bodyX - 5 * d, bodyY - 3 * d, 4 * d, p)
            c.drawCircle(bodyX + 5 * d, bodyY + 4 * d, 3 * d, p)
            c.drawCircle(bodyX + 4 * d, bodyY - 6 * d, 2 * d, p)
        }
        val ca = cloudAlpha(phase)
        for (i in 0 until 3) {
            val x = ((CLOUD_BASE[i] + time * (0.004f + i * 0.0015f)) % 1.35f) * (w + 120 * d) - 90 * d
            cloud(c, x, h * (0.17f + 0.14f * i), (40 + i * 10) * d, ca)
        }
        p.color = hillBack(phase); c.drawPath(hill1, p)
        p.color = hillFront(phase); c.drawPath(hill2, p)
        if (lightText(phase)) { p.shader = scrimShader; c.drawRect(0f, h * 0.35f, w, h, p); p.shader = null }
        c.restore()
        postInvalidateDelayed(66)
    }
}

/** The Home "scene": sky + greeting text that adapts its colour to the time of day. */
internal fun MainActivity.buildSkyHero(title: String, sub: String): FrameLayout {
    val cal = Calendar.getInstance()
    val hr = cal.get(Calendar.HOUR_OF_DAY)
    val phase = Smart.phaseOf(hr)
    val hourF = hr + cal.get(Calendar.MINUTE) / 60f
    val main = if (SkyView.lightText(phase)) Color.WHITE else SkyView.darkInk(phase)
    val frame = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(200)).apply { setMargins(0, dp(10), 0, dp(6)) } }
    frame.addView(SkyView(this, phase, hourF), FrameLayout.LayoutParams(-1, -1))
    val date = SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID")).format(cal.time)
    frame.addView(text(date, 12f, true, main).apply { alpha = 0.85f; setPadding(dp(22), dp(18), dp(22), 0) }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), 0, dp(22), dp(18)) }
    col.addView(text(title, 28f, true, main))
    col.addView(text(sub, 13f, false, main).apply { alpha = 0.92f })
    val maxW = ((resources.displayMetrics.widthPixels - dp(32)) * 0.72f).toInt()
    frame.addView(col, FrameLayout.LayoutParams(maxW, -2, Gravity.BOTTOM or Gravity.START))
    return frame
}
