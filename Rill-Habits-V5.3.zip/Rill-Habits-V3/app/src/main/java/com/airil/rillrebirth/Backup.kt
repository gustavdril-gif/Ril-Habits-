package com.airil.rillrebirth

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Whole-app backup: every value in the app's single preferences file goes into one JSON file. */
object Backup {
    private const val MARK = "RilHabit"
    private const val PREFS = "rill_data"
    const val REQ_EXPORT = 4101
    const val REQ_IMPORT = 4102

    fun export(c: Context): String {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val data = JSONObject()
        for ((key, value) in p.all) {
            val o = JSONObject()
            when (value) {
                is String -> o.put("t", "s").put("v", value)
                is Boolean -> o.put("t", "b").put("v", value)
                is Int -> o.put("t", "i").put("v", value)
                is Long -> o.put("t", "l").put("v", value)
                is Float -> o.put("t", "f").put("v", value.toDouble())
                is Set<*> -> o.put("t", "ss").put("v", JSONArray(value.map { it.toString() }))
                else -> continue
            }
            data.put(key, o)
        }
        return JSONObject().put("app", MARK).put("version", 1).put("exported", System.currentTimeMillis()).put("data", data).toString()
    }

    /** Parses and validates without touching current data. Returns the parsed root or null. */
    fun parse(json: String): JSONObject? = try {
        val root = JSONObject(json)
        if (root.optString("app") == MARK && root.optJSONObject("data") != null) root else null
    } catch (_: Exception) { null }

    fun summary(root: JSONObject): String {
        val data = root.optJSONObject("data") ?: return ""
        fun count(key: String): Int = try { JSONArray(data.optJSONObject(key)?.optString("v") ?: "[]").length() } catch (_: Exception) { 0 }
        val date = root.optLong("exported", 0L).let { if (it > 0) SimpleDateFormat("d MMM yyyy HH:mm", Locale("id", "ID")).format(Date(it)) else "-" }
        return "Dibuat: $date\nKegiatan: ${count("tasks_json")} · Workout: ${count("workouts_v2_json")} · Catatan: ${count("notes_json")} · Target: ${count("goals_json")}"
    }

    fun restore(c: Context, root: JSONObject): Boolean {
        val data = root.optJSONObject("data") ?: return false
        val ed = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear()
        val keys = data.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val o = data.optJSONObject(key) ?: continue
            when (o.optString("t")) {
                "s" -> ed.putString(key, o.optString("v"))
                "b" -> ed.putBoolean(key, o.optBoolean("v"))
                "i" -> ed.putInt(key, o.optInt("v"))
                "l" -> ed.putLong(key, o.optLong("v"))
                "f" -> ed.putFloat(key, o.optDouble("v").toFloat())
                "ss" -> {
                    val a = o.optJSONArray("v") ?: JSONArray()
                    val set = HashSet<String>()
                    for (i in 0 until a.length()) set.add(a.optString(i))
                    ed.putStringSet(key, set)
                }
            }
        }
        return ed.commit()
    }
}

internal fun MainActivity.startBackupExport() {
    val name = "rilhabit-backup-${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())}.json"
    val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, name) }
    try { startActivityForResult(i, Backup.REQ_EXPORT) } catch (_: Exception) { Toast.makeText(this, "Tidak ada aplikasi file untuk menyimpan cadangan.", Toast.LENGTH_LONG).show() }
}

internal fun MainActivity.startBackupImport() {
    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
    try { startActivityForResult(i, Backup.REQ_IMPORT) } catch (_: Exception) { Toast.makeText(this, "Tidak ada aplikasi file untuk memilih cadangan.", Toast.LENGTH_LONG).show() }
}

/** Called from MainActivity.onActivityResult. */
internal fun MainActivity.handleBackupResult(requestCode: Int, resultCode: Int, uri: Uri?) {
    if (resultCode != Activity.RESULT_OK || uri == null) return
    if (requestCode == Backup.REQ_EXPORT) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(Backup.export(this).toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "Cadangan tersimpan ✅", Toast.LENGTH_LONG).show()
        } catch (_: Exception) { Toast.makeText(this, "Gagal menyimpan cadangan.", Toast.LENGTH_LONG).show() }
    } else if (requestCode == Backup.REQ_IMPORT) {
        val text = try { contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } } catch (_: Exception) { null }
        val root = if (text == null) null else Backup.parse(text)
        if (root == null) { Toast.makeText(this, "File ini bukan cadangan RilHabit yang valid.", Toast.LENGTH_LONG).show(); return }
        AlertDialog.Builder(this, R.style.RillDialog).setTitle("Pulihkan data?")
            .setMessage("${Backup.summary(root)}\n\nSemua data di HP ini akan diganti dengan isi cadangan.")
            .setPositiveButton("Pulihkan") { _, _ ->
                if (Backup.restore(this, root)) {
                    ReminderScheduler.scheduleAll(this)
                    RillWidget.updateAll(this)
                    selectedTab = "Home"; render(true)
                    Toast.makeText(this, "Data berhasil dipulihkan ✅", Toast.LENGTH_LONG).show()
                } else Toast.makeText(this, "Gagal memulihkan data.", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Batal", null).show()
    }
}

/** Card in the Jadwal tab. */
internal fun MainActivity.backupCard() {
    val c = card(14)
    c.addView(text("💾 Data & cadangan", 16f, true))
    c.addView(hint("Simpan semua kegiatan, workout, catatan, dan target ke satu file. Berguna saat ganti HP atau memasang ulang aplikasi."))
    c.addView(pair(button("Cadangkan") { startBackupExport() }, button("Pulihkan") { startBackupImport() }))
    content.addView(c)
}
